//+------------------------------------------------------------------+
//|                                          News_Breakout_2030_EA.mq4 |
//|  20:30 结束的瞬间同时开多空单，每单 0.02 手，按美元金额设置止损    |
//+------------------------------------------------------------------+
#property copyright "Auto-generated"
#property version   "1.10"
#property strict

input double InpLots         = 0.02;   // 每单手数
input double InpRiskUSD      = 5.0;    // 每单最大亏损（美元）
input int    InpTriggerHour  = 12;     // 触发小时（交易平台时间，24小时制）
input int    InpTriggerMinute= 30;     // 触发分钟
input int    InpTriggerSecond= 58;     // 触发秒数
input int    InpMagic        = 20250812; // 魔术号
input int    InpSlippage     = 30;     // 允许滑点（点）
input bool   InpDebugMode    = false;  // 调试模式：打印每tick状态
input bool   InpTestMode     = false;  // 测试模式：挂上去后立即开一单测试

datetime g_todayDate       = 0;
bool     g_triggeredToday  = false;
int      g_lastSecond      = -1;

//+------------------------------------------------------------------+
int OnInit()
{
   g_todayDate      = 0;
   g_triggeredToday = false;
   g_lastSecond     = -1;

   if(InpTestMode)
      Print("测试模式已开启：EA 挂上去后会在第一笔 tick 立即开仓测试");
   else
      Print("News_Breakout_2030_EA 初始化完成，将在 ", InpTriggerHour, ":", InpTriggerMinute, ":", InpTriggerSecond, " 开多空单各 ", InpLots, " 手");

   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
void OnTick()
{
   datetime now   = TimeCurrent();
   datetime today = StringToTime(TimeToStr(now, TIME_DATE));

   // 日期变化时重置每日状态
   if(g_todayDate != today)
   {
      g_todayDate      = today;
      g_triggeredToday = false;
      g_lastSecond     = -1;
   }

   MqlDateTime dt;
   TimeToStruct(now, dt);
   int currentHour   = dt.hour;
   int currentMinute = dt.min;
   int currentSecond = dt.sec;

   // 调试打印
   if(InpDebugMode)
   {
      Print("DEBUG 时间=", TimeToStr(now, TIME_SECONDS),
            " 目标=", InpTriggerHour, ":", InpTriggerMinute, ":", InpTriggerSecond,
            " triggeredToday=", g_triggeredToday);
   }

   // 测试模式：第一笔 tick 立即执行（仅一次）
   if(InpTestMode && !g_triggeredToday)
   {
      Print("测试模式触发，当前时间 ", TimeToStr(now, TIME_SECONDS));
      TryOpenOrders(now);
      return;
   }

   // 当天已触发过则跳过
   if(g_triggeredToday)
      return;

   // 只在精确的目标秒数触发一次
   if(currentHour != InpTriggerHour ||
      currentMinute != InpTriggerMinute ||
      currentSecond != InpTriggerSecond)
      return;

   // 防止同一秒内多次开仓（如果同一秒收到多笔 tick）
   if(g_lastSecond == currentSecond)
      return;

   g_lastSecond = currentSecond;
   TryOpenOrders(now);
}

//+------------------------------------------------------------------+
void TryOpenOrders(datetime now)
{
   if(!CanTradeNow())
   {
      Print("当前不允许交易，跳过本次触发。时间=", TimeToStr(now, TIME_SECONDS));
      return;
   }

   if(OpenDualOrders())
   {
      g_triggeredToday = true;
      Print("已成功在 ", TimeToStr(now, TIME_SECONDS), " 开多空单");
   }
   else
   {
      Print("本次触发开仓失败，将在下一笔报价重试。时间=", TimeToStr(now, TIME_SECONDS));
   }
}

//+------------------------------------------------------------------+
bool CanTradeNow()
{
   if(!IsTradeAllowed(Symbol(), TimeCurrent()))
      return false;
   if(IsTradeContextBusy())
      return false;
   return true;
}

//+------------------------------------------------------------------+
bool OpenDualOrders()
{
   RefreshRates();

   double tickValue = MarketInfo(Symbol(), MODE_TICKVALUE);
   double tickSize  = MarketInfo(Symbol(), MODE_TICKSIZE);
   int    digits    = (int)MarketInfo(Symbol(), MODE_DIGITS);

   if(tickValue <= 0 || tickSize <= 0)
   {
      Print("错误：无法获取合约的 TICKVALUE 或 TICKSIZE");
      return false;
   }

   // 计算每单亏损 InpRiskUSD 所需的价格距离
   double priceDistance = NormalizeDouble((InpRiskUSD / (InpLots * tickValue)) * tickSize, digits);

   if(priceDistance <= 0)
   {
      Print("错误：计算出的止损距离为 0，tickValue=", tickValue, " tickSize=", tickSize);
      return false;
   }

   double slBuy  = NormalizeDouble(Ask - priceDistance, digits);
   double slSell = NormalizeDouble(Bid + priceDistance, digits);

   // 检查止损距离是否满足券商最小要求
   int    stopLevel   = (int)MarketInfo(Symbol(), MODE_STOPLEVEL);
   double minDistance = stopLevel * tickSize;
   if(NormalizeDouble(Ask - slBuy, digits) < minDistance ||
      NormalizeDouble(slSell - Bid, digits) < minDistance)
   {
      Print("错误：计算出的止损距离小于券商允许的 STOPLEVEL (", stopLevel, " 点)");
      return false;
   }

   int ticketBuy = OrderSend(Symbol(), OP_BUY,  InpLots, Ask, InpSlippage,
                              slBuy, 0, "News breakout BUY",  InpMagic, 0, clrGreen);

   int ticketSell = OrderSend(Symbol(), OP_SELL, InpLots, Bid, InpSlippage,
                               slSell, 0, "News breakout SELL", InpMagic, 0, clrRed);

   if(ticketBuy < 0)
      Print("多单开仓失败，错误码: ", GetLastError());
   if(ticketSell < 0)
      Print("空单开仓失败，错误码: ", GetLastError());

   return (ticketBuy > 0 && ticketSell > 0);
}
//+------------------------------------------------------------------+
