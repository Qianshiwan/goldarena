//+------------------------------------------------------------------+
//|                               adaptive_trend_strategy_v8_micro.mq4|
//|                        v8 Micro 小资金固定手数 MT4 版本            |
//|  核心逻辑：                                                        |
//|  1. 可配置时间周期交易，双向                                       |
//|  2. V8 原 trend_follow + Donchian 入场保留不变                     
//|  3. 新增可选 MA 缎带排列过滤（5/20/60/80）                         
//|  4. ATR 计算止损与跟踪止损                                         
//|  5. 慢周期 MA + 斜率 做趋势方向过滤                                
//|  6. Donchian Channel 作为辅助入场（需满足 MA 缎带过滤）            
//|  6. 角度过滤（fast_ma / fast_upper）                               |
//|  7. 新增：UseFixedLot + FixedLotSize，固定开仓 0.01 手             
//|  8. XAUUSD 15m 优选版 v2 默认参数 + RSI 超买超卖过滤                
//+------------------------------------------------------------------+
#property copyright "v8 Micro MT4 Port"
#property link      ""
#property version   "1.00"
#property strict

#define PI 3.14159265358979323846

//--- 输入参数
input int    InpTimeFrame         = 15;      // 交易时间周期（分钟：1,5,15,30,60,240,1440）
input int    InpFastMAPeriod      = 21;      // Fast MA 周期
input double InpFastBBMult        = 1.5;     // 布林带倍数
input int    InpSlowMAPeriod      = 50;      // 慢周期 MA（趋势方向）
input int    InpEntryMA1          = 5;       // 入场快线周期
input int    InpEntryMA2          = 20;      // 入场周期2
input int    InpEntryMA3          = 60;      // 入场周期3
input int    InpEntryMA4          = 80;      // 入场慢线周期
input bool   InpUsePullbackEntry  = false;   // 启用 MA20 回踩反转入场
input int    InpPullbackLookback  = 20;      // 回踩反转回看 K 线数
input int    InpATRPeriod         = 14;      // ATR 周期
input int    InpDonchianPeriod    = 20;      // 唐奇安通道周期
input double InpStopATRMult       = 2.5;     // 初始止损 ATR 倍数（XAUUSD 15m 扫描优化值）
input double InpTrailATRMult      = 3.5;     // 跟踪止损 ATR 倍数（v2 出场保护优化值）
input bool   InpUseAngleFilter    = false;   // 启用角度过滤（M15 趋势由 MA21+缎带体现，默认关闭）
input int    InpAngleLookback     = 3;       // 角度回望周期（XAUUSD 15m 扫描优化值）
input double InpMinAngle          = 30.0;    // 最小入场角度（度）（XAUUSD 15m 扫描优化值）
input double InpStrongAngle       = 55.0;    // 强角度阈值（度）
input bool   InpUseTrendDirection = false;   // 启用趋势方向过滤
input bool   InpUseVolumeFilter   = false;   // 启用成交量过滤
input double InpVolumeThreshold   = 1.0;     // 成交量需大于均量的倍数
input bool   InpUseDailyTrend     = false;   // 启用日线趋势过滤
input int    InpDailyMAPeriod     = 20;      // 日线 MA 周期
input bool   InpUseChandelierTrail = false;  // 启用吊灯线跟踪止损
input bool   InpUseTrailingStop   = false;   // 启用 ATR 跟踪止损
input bool   InpUseBreakeven      = false;   // 启用保本止损
input double InpBEProfitATRMult   = 2.5;     // 浮盈达到 N*ATR 后启动保本（Python优化：2.0->2.5）
input double InpBEATRMult         = 2.0;     // 保本止损设为入场价 + N*ATR
input bool   InpUseFixedATRBreakeven = true; // 使用开仓时 ATR 计算保本（true=固定ATR，false=动态ATR）
input bool   InpOnlyLong          = false;   // 只做多
input bool   InpUseFixedLot       = true;    // 使用固定手数
input double InpFixedLotSize      = 0.01;    // 固定手数（XAUUSD 15m Micro 优选版）
input double InpRiskPercent       = 2.0;     // 单笔风险百分比（UseFixedLot=true 时无效）
input double InpMaxLot            = 0.02;    // 最大手数（支持两位小数，如 0.01/0.02/0.05）
input bool   InpShow              = true;    // 显示K线剩余时间（右上角黄色）
input double InpManualSLDollar    = 5.0;     // 手动单亏损达到多少美元自动止损（0=关闭）

//--- MACD 过滤
input bool   InpUseMACDFilter     = false;   // 启用 MACD 过滤
input int    InpMACDFast          = 12;      // MACD 快线周期
input int    InpMACDSlow          = 26;      // MACD 慢线周期
input int    InpMACDSignal        = 9;       // MACD 信号线周期
input bool   InpMACDBanShortOnCross = true;  // MACD 金叉时禁止做空
input bool   InpMACDBanLongOnCross  = true;  // MACD 死叉时禁止做多

//--- 近期极值过滤
input bool   InpUseNearExtremeFilter = false; // 启用近期极值过滤（XAUUSD 15m 扫描优化值）
input int    InpNearExtremeLookback  = 20;   // 近期极值回看 K 线数
input double InpNearExtremeATRMult   = 0.3;  // 距离极值小于 N*ATR 时不开仓

//--- RSI 超买超卖过滤
input bool   InpUseRSIFilter        = false; // 启用 RSI 过滤
input int    InpRSIPeriod           = 14;    // RSI 周期
input double InpRSILongMax          = 75.0;  // RSI 高于此值禁止做多
input double InpRSIShortMin         = 30.0;  // RSI 低于此值禁止做空

input int    InpMagicNumber       = 800809;  // 魔术号
input string InpTradeComment      = "v8_micro"; // 订单注释
input int    InpSlippage          = 30;      // 滑点（点）

//--- 全局变量
int    g_ticket = 0;
double g_entryPrice = 0.0;
double g_stopLoss = 0.0;
double g_highestHigh = 0.0;
double g_lowestLow = 0.0;
double g_entryATR = 0.0;
bool   g_breakevenMoved = false;
datetime g_lastBarTime = 0;

//+------------------------------------------------------------------+
//| 根据输入返回 MT4 时间周期枚举                                       |
//+------------------------------------------------------------------+
int GetTradePeriod()
{
   if(InpTimeFrame == 1) return PERIOD_M1;
   if(InpTimeFrame == 5) return PERIOD_M5;
   if(InpTimeFrame == 15) return PERIOD_M15;
   if(InpTimeFrame == 30) return PERIOD_M30;
   if(InpTimeFrame == 60) return PERIOD_H1;
   if(InpTimeFrame == 240) return PERIOD_H4;
   if(InpTimeFrame == 1440) return PERIOD_D1;
   return PERIOD_M15;
}

//+------------------------------------------------------------------+
//| 显示当前K线剩余时间（黄色大字，右上角）                              |
//+------------------------------------------------------------------+
void ShowInfo()
{
   if(!InpShow)
   {
      ObjectDelete(0, "v8_micro_TimeLeft");
      ObjectDelete(0, "battertest_V8_TimeLeft");
      Comment("");
      return;
   }

   string objName = "battertest_V8_TimeLeft";
   if(ObjectFind(0, objName) < 0)
   {
      if(!ObjectCreate(0, objName, OBJ_LABEL, 0, 0, 0))
      {
         Print("[battertest-V8] 创建时间标签失败");
         return;
      }
      ObjectSetInteger(0, objName, OBJPROP_CORNER, CORNER_RIGHT_UPPER);
      ObjectSetInteger(0, objName, OBJPROP_XDISTANCE, 180);
      ObjectSetInteger(0, objName, OBJPROP_YDISTANCE, 20);
      ObjectSetInteger(0, objName, OBJPROP_BACK, false);
      ObjectSetInteger(0, objName, OBJPROP_SELECTABLE, false);
      ObjectSetInteger(0, objName, OBJPROP_TIMEFRAMES, OBJ_ALL_PERIODS);
      ObjectSetInteger(0, objName, OBJPROP_FONTSIZE, 14);
      ObjectSetInteger(0, objName, OBJPROP_COLOR, clrYellow);
   }

   datetime nextBarTime = Time[0] + Period() * 60;
   int remaining = (int)(nextBarTime - TimeCurrent());
   if(remaining < 0) remaining = 0;
   string text = StringFormat("K线剩余: %02d:%02d", remaining / 60, remaining % 60);
   ObjectSetString(0, objName, OBJPROP_TEXT, text);

   // 备用显示：左上角 Comment
   Comment(text);
}

//+------------------------------------------------------------------+
//| 检查手动单亏损并自动止损                                            |
//+------------------------------------------------------------------+
void CheckManualStopLoss()
{
   if(InpManualSLDollar <= 0.0) return;
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES))
      {
         if(OrderMagicNumber() == InpMagicNumber) continue;
         if(OrderSymbol() != Symbol()) continue;

         double profit = OrderProfit() + OrderSwap() + OrderCommission();
         if(profit <= -InpManualSLDollar)
         {
            int ticket = OrderTicket();
            bool ok = false;
            if(OrderType() == OP_BUY)
               ok = OrderClose(ticket, OrderLots(), Bid, InpSlippage, clrRed);
            else if(OrderType() == OP_SELL)
               ok = OrderClose(ticket, OrderLots(), Ask, InpSlippage, clrGreen);
            if(!ok) LogError("手动单止损平仓");
         }
      }
   }
}

//+------------------------------------------------------------------+
//| 计算成交量均线                                                      |
//+------------------------------------------------------------------+
double VolumeMA(int period, int shift)
{
   if(period <= 0) return 0.0;
   int tf = GetTradePeriod();
   double sum = 0.0;
   for(int i = shift; i < shift + period; i++)
   {
      long vol = iVolume(Symbol(), tf, i);
      if(vol < 0) return 0.0;
      sum += (double)vol;
   }
   return sum / period;
}

//+------------------------------------------------------------------+
//| 计算均线角度（度）                                                  |
//+------------------------------------------------------------------+
double CalcMAAngle(int shift)
{
   int tf = GetTradePeriod();
   double maNow = iMA(Symbol(), tf, InpFastMAPeriod, 0, MODE_SMA, PRICE_CLOSE, shift);
   double maPrev = iMA(Symbol(), tf, InpFastMAPeriod, 0, MODE_SMA, PRICE_CLOSE, shift + InpAngleLookback);
   if(maPrev == 0.0 || InpAngleLookback <= 0) return 0.0;
   return MathArctan((maNow - maPrev) / InpAngleLookback) * 180.0 / PI;
}

//+------------------------------------------------------------------+
//| 计算布林上轨角度（度）                                              |
//+------------------------------------------------------------------+
double CalcUpperAngle(int shift)
{
   int tf = GetTradePeriod();
   double upperNow = iBands(Symbol(), tf, InpFastMAPeriod, InpFastBBMult, 0, PRICE_CLOSE, MODE_UPPER, shift);
   double upperPrev = iBands(Symbol(), tf, InpFastMAPeriod, InpFastBBMult, 0, PRICE_CLOSE, MODE_UPPER, shift + InpAngleLookback);
   if(upperPrev == 0.0 || InpAngleLookback <= 0) return 0.0;
   return MathArctan((upperNow - upperPrev) / InpAngleLookback) * 180.0 / PI;
}

//+------------------------------------------------------------------+
//| 检查过去 lookback 根 K 线内是否出现过 MA5 下穿 MA20                 |
//+------------------------------------------------------------------+
bool WasFastCrossDownSlow(int lookback)
{
   int tf = GetTradePeriod();
   for(int i = 2; i <= lookback + 1; i++)
   {
      double ma1 = iMA(Symbol(), tf, InpEntryMA1, 0, MODE_SMA, PRICE_CLOSE, i);
      double ma2 = iMA(Symbol(), tf, InpEntryMA2, 0, MODE_SMA, PRICE_CLOSE, i);
      double ma1Prev = iMA(Symbol(), tf, InpEntryMA1, 0, MODE_SMA, PRICE_CLOSE, i + 1);
      double ma2Prev = iMA(Symbol(), tf, InpEntryMA2, 0, MODE_SMA, PRICE_CLOSE, i + 1);
      if(ma1 == 0.0 || ma2 == 0.0 || ma1Prev == 0.0 || ma2Prev == 0.0) continue;
      if(ma1 < ma2 && !(ma1Prev < ma2Prev)) return true;
   }
   return false;
}

//+------------------------------------------------------------------+
//| 检查过去 lookback 根 K 线内是否出现过 MA5 上穿 MA20                 |
//+------------------------------------------------------------------+
bool WasFastCrossUpSlow(int lookback)
{
   int tf = GetTradePeriod();
   for(int i = 2; i <= lookback + 1; i++)
   {
      double ma1 = iMA(Symbol(), tf, InpEntryMA1, 0, MODE_SMA, PRICE_CLOSE, i);
      double ma2 = iMA(Symbol(), tf, InpEntryMA2, 0, MODE_SMA, PRICE_CLOSE, i);
      double ma1Prev = iMA(Symbol(), tf, InpEntryMA1, 0, MODE_SMA, PRICE_CLOSE, i + 1);
      double ma2Prev = iMA(Symbol(), tf, InpEntryMA2, 0, MODE_SMA, PRICE_CLOSE, i + 1);
      if(ma1 == 0.0 || ma2 == 0.0 || ma1Prev == 0.0 || ma2Prev == 0.0) continue;
      if(ma1 > ma2 && !(ma1Prev > ma2Prev)) return true;
   }
   return false;
}

//+------------------------------------------------------------------+
//| 获取每个点的美元价值（近似）                                        |
//+------------------------------------------------------------------+
double GetPipValue()
{
   if(StringFind(Symbol(), "XAU") >= 0 || StringFind(Symbol(), "GOLD") >= 0)
      return 1.0;
   return MarketInfo(Symbol(), MODE_TICKVALUE) / MarketInfo(Symbol(), MODE_TICKSIZE) * Point;
}

//+------------------------------------------------------------------+
//| 计算手数：固定手数模式优先                                          |
//+------------------------------------------------------------------+
double CalcLotSize(double stopDistance, double angleMult)
{
   double lots;
   if(InpUseFixedLot)
   {
      lots = InpFixedLotSize;
   }
   else
   {
      if(stopDistance <= 0.0) return 0.0;
      double riskAmount = AccountBalance() * InpRiskPercent / 100.0;
      double tickSize   = MarketInfo(Symbol(), MODE_TICKSIZE);
      double tickValue  = MarketInfo(Symbol(), MODE_TICKVALUE);
      if(tickSize <= 0.0 || tickValue <= 0.0) return 0.0;
      lots = riskAmount * angleMult / (stopDistance / tickSize * tickValue);
   }

   double minLot = MarketInfo(Symbol(), MODE_MINLOT);
   double maxLot = MarketInfo(Symbol(), MODE_MAXLOT);
   double lotStep = MarketInfo(Symbol(), MODE_LOTSTEP);
   if(lotStep <= 0.0) lotStep = 0.01;

   lots = MathFloor(lots / lotStep) * lotStep;
   lots = MathMax(minLot, MathMin(maxLot, lots));
   lots = MathMin(lots, InpMaxLot);
   return NormalizeDouble(lots, 2);
}

//+------------------------------------------------------------------+
//| 检查当前是否有持仓                                                  |
//+------------------------------------------------------------------+
bool HasPosition()
{
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES))
      {
         if(OrderMagicNumber() == InpMagicNumber && OrderSymbol() == Symbol())
            return true;
      }
   }
   return false;
}

//+------------------------------------------------------------------+
//| 错误码转描述                                                        |
//+------------------------------------------------------------------+
string ErrorDescription(int error_code)
{
   switch(error_code)
   {
      case 0:   return "无错误";
      case 1:   return "无错误结果";
      case 2:   return "常见错误";
      case 3:   return "无效参数";
      case 4:   return "交易服务器繁忙";
      case 5:   return "旧版本客户端";
      case 6:   return "无连接";
      case 7:   return "非交易权限";
      case 8:   return "价格过高";
      case 9:   return "无效止损";
      case 10:  return "无效手数";
      case 11:  return "市场关闭";
      case 12:  return "禁止交易";
      case 13:  return "资金不足";
      case 14:  return "价格已变";
      case 15:  return "报价关闭";
      case 16:  return "自动交易关闭";
      case 17:  return "订单已处理";
      case 18:  return "禁止买入";
      case 19:  return "禁止卖出";
      case 20:  return "无效订单";
      case 21:  return "无效交易请求";
      case 22:  return "无最新报价";
      case 23:  return "无效价格";
      case 24:  return "无效止损";
      case 25:  return "无效止盈";
      case 26:  return "无效订单类型";
      case 27:  return "禁止交易";
      case 28:  return "交易被锁定";
      case 29:  return "订单被锁定";
      case 30:  return "无效成交";
      case 31:  return "无效请求";
      case 32:  return "无连接";
      case 33:  return "超时";
      case 34:  return "无效价格";
      case 35:  return "无效请求";
      case 36:  return "市场报价关闭";
      case 37:  return "交易被禁用";
      case 38:  return "无最新报价";
      case 39:  return "请求过于频繁";
      case 40:  return "自动交易关闭";
      case 41:  return "流水号已满";
      case 42:  return "禁止 Hedge";
      case 43:  return "禁止 FIFO";
      case 64:  return "账户被禁用";
      case 65:  return "无效账户";
      case 128: return "交易超时";
      case 129: return "无效价格";
      case 130: return "无效止损";
      case 131: return "无效手数";
      case 132: return "市场关闭";
      case 133: return "禁止交易";
      case 134: return "资金不足";
      case 135: return "价格已变";
      case 136: return "无报价";
      case 137: return "经纪商繁忙";
      case 138: return "重新报价";
      case 139: return "订单被锁定";
      case 140: return "仅允许平仓";
      case 141: return "交易限制";
      case 145: return "修改失败";
      case 146: return "交易环境繁忙";
      case 147: return "交易失败";
      case 148: return "无效订单";
      case 149: return "无效请求";
      case 150: return "无效参数";
      default:  return "未知错误";
   }
}

//+------------------------------------------------------------------+
//| 输出错误日志                                                        |
//+------------------------------------------------------------------+
void LogError(string action)
{
   int err = GetLastError();
   if(err != ERR_NO_ERROR)
   {
      Print("[v8_micro ERROR] ", action, " 错误码: ", err, " 描述: ", ErrorDescription(err));
   }
}

//+------------------------------------------------------------------+
//| 获取持仓方向：1=多，-1=空，0=无                                     |
//+------------------------------------------------------------------+
int GetPositionDir()
{
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES))
      {
         if(OrderMagicNumber() == InpMagicNumber && OrderSymbol() == Symbol())
         {
            if(OrderType() == OP_BUY)  return 1;
            if(OrderType() == OP_SELL) return -1;
         }
      }
   }
   return 0;
}

//+------------------------------------------------------------------+
//| 平掉当前持仓（带错误处理）                                          |
//+------------------------------------------------------------------+
void ClosePosition()
{
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES))
      {
         if(OrderMagicNumber() == InpMagicNumber && OrderSymbol() == Symbol())
         {
            int ticket = OrderTicket();
            bool ok = false;
            if(OrderType() == OP_BUY)
               ok = OrderClose(ticket, OrderLots(), Bid, InpSlippage, clrRed);
            else if(OrderType() == OP_SELL)
               ok = OrderClose(ticket, OrderLots(), Ask, InpSlippage, clrGreen);
            if(ok)
               Print("[v8_micro] 平仓成功 Ticket=", ticket, " 盈亏=", OrderProfit());
            else
               LogError("平仓");
         }
      }
   }
}

//+------------------------------------------------------------------+
//| 修改止损（带错误处理）                                              |
//+------------------------------------------------------------------+
void ModifyStopLoss(double newSL)
{
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES))
      {
         if(OrderMagicNumber() == InpMagicNumber && OrderSymbol() == Symbol())
         {
            double oldSL = OrderStopLoss();
            if(MathAbs(newSL - oldSL) > Point * 0.5)
            {
               bool ok = OrderModify(OrderTicket(), OrderOpenPrice(), NormalizeDouble(newSL, Digits), OrderTakeProfit(), 0, clrBlue);
               if(ok)
                  Print("[v8_micro] 移动止损 Ticket=", OrderTicket(), " 新止损=", newSL);
               else
                  LogError("移动止损");
            }
         }
      }
   }
}

//+------------------------------------------------------------------+
//| 开多单（带错误处理）                                                |
//+------------------------------------------------------------------+
void OpenBuy(double sl, double angleMult)
{
   double lots = CalcLotSize(MathAbs(Ask - sl), angleMult);
   if(lots <= 0.0)
   {
      Print("[v8_micro] 开多单失败：计算手数为0");
      return;
   }
   int ticket = OrderSend(Symbol(), OP_BUY, lots, Ask, InpSlippage, NormalizeDouble(sl, Digits), 0, InpTradeComment, InpMagicNumber, 0, clrGreen);
   if(ticket > 0)
   {
      g_ticket = ticket;
      g_entryPrice = Ask;
      g_stopLoss = sl;
      g_highestHigh = iHigh(Symbol(), GetTradePeriod(), 0);
      g_entryATR = iATR(Symbol(), GetTradePeriod(), InpATRPeriod, 1);
      g_breakevenMoved = false;
      Print("[v8_micro] 开多单成功 Ticket=", ticket, " 手数=", lots, " 入场=", Ask, " 止损=", sl, " ATR=", g_entryATR);
   }
   else
   {
      LogError("开多单");
   }
}

//+------------------------------------------------------------------+
//| 开空单（带错误处理）                                                |
//+------------------------------------------------------------------+
void OpenSell(double sl, double angleMult)
{
   double lots = CalcLotSize(MathAbs(sl - Bid), angleMult);
   if(lots <= 0.0)
   {
      Print("[v8_micro] 开空单失败：计算手数为0");
      return;
   }
   int ticket = OrderSend(Symbol(), OP_SELL, lots, Bid, InpSlippage, NormalizeDouble(sl, Digits), 0, InpTradeComment, InpMagicNumber, 0, clrRed);
   if(ticket > 0)
   {
      g_ticket = ticket;
      g_entryPrice = Bid;
      g_stopLoss = sl;
      g_lowestLow = iLow(Symbol(), GetTradePeriod(), 0);
      g_entryATR = iATR(Symbol(), GetTradePeriod(), InpATRPeriod, 1);
      g_breakevenMoved = false;
      Print("[v8_micro] 开空单成功 Ticket=", ticket, " 手数=", lots, " 入场=", Bid, " 止损=", sl, " ATR=", g_entryATR);
   }
   else
   {
      LogError("开空单");
   }
}

//+------------------------------------------------------------------+
//| EA 启动时恢复持仓状态                                               |
//+------------------------------------------------------------------+
void RestorePosition()
{
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES))
      {
         if(OrderMagicNumber() == InpMagicNumber && OrderSymbol() == Symbol())
         {
            g_ticket = OrderTicket();
            g_entryPrice = OrderOpenPrice();
            g_stopLoss = OrderStopLoss();
            int tf = GetTradePeriod();
            datetime openTime = OrderOpenTime();
            int barsSinceOpen = iBarShift(Symbol(), tf, openTime);
            if(barsSinceOpen < 1) barsSinceOpen = 1;
            g_entryATR = iATR(Symbol(), tf, InpATRPeriod, barsSinceOpen);
            if(g_entryATR <= 0.0) g_entryATR = iATR(Symbol(), tf, InpATRPeriod, 1);
            if(OrderType() == OP_BUY)
            {
               int highestIdx = iHighest(Symbol(), tf, MODE_HIGH, barsSinceOpen, 1);
               g_highestHigh = iHigh(Symbol(), tf, highestIdx);
               double beLevel = g_entryPrice + InpBEATRMult * g_entryATR;
               g_breakevenMoved = (g_stopLoss >= beLevel - Point * 0.5);
            }
            else
            {
               int lowestIdx = iLowest(Symbol(), tf, MODE_LOW, barsSinceOpen, 1);
               g_lowestLow = iLow(Symbol(), tf, lowestIdx);
               double beLevel = g_entryPrice - InpBEATRMult * g_entryATR;
               g_breakevenMoved = (g_stopLoss <= beLevel + Point * 0.5);
            }
            Print("[v8_micro] 启动恢复持仓 Ticket=", g_ticket, " 方向=", (OrderType() == OP_BUY ? "多" : "空"),
                  " 入场=", g_entryPrice, " 止损=", g_stopLoss, " 开仓ATR=", g_entryATR, " 保本已启动=", g_breakevenMoved);
            return;
         }
      }
   }
}

//+------------------------------------------------------------------+
//| MACD Histogram 值                                                   |
//+------------------------------------------------------------------+
double MACDHistogram(int shift)
{
   double macdMain = iMACD(Symbol(), GetTradePeriod(), InpMACDFast, InpMACDSlow, InpMACDSignal, PRICE_CLOSE, MODE_MAIN, shift);
   double macdSignal = iMACD(Symbol(), GetTradePeriod(), InpMACDFast, InpMACDSlow, InpMACDSignal, PRICE_CLOSE, MODE_SIGNAL, shift);
   return macdMain - macdSignal;
}

//+------------------------------------------------------------------+
//| 检查 MACD 是否金叉/死叉                                             |
//+------------------------------------------------------------------+
void CheckMACDCross(bool &bullishCross, bool &bearishCross)
{
   bullishCross = false;
   bearishCross = false;
   if(!InpUseMACDFilter) return;
   double histNow = MACDHistogram(1);
   double histPrev = MACDHistogram(2);
   if(histNow >= 0 && histPrev < 0) bullishCross = true;
   if(histNow < 0 && histPrev >= 0) bearishCross = true;
}

//+------------------------------------------------------------------+
//| 近期极值过滤                                                        |
//+------------------------------------------------------------------+
bool NearExtremeAllowsLong(double atr)
{
   if(!InpUseNearExtremeFilter) return true;
   int tf = GetTradePeriod();
   int lookback = MathMax(1, InpNearExtremeLookback);
   int highestIdx = iHighest(Symbol(), tf, MODE_HIGH, lookback, 1);
   if(highestIdx < 0) return true;
   double recentHigh = High[highestIdx];
   if((recentHigh - Close[1]) < InpNearExtremeATRMult * atr) return false;
   return true;
}

bool NearExtremeAllowsShort(double atr)
{
   if(!InpUseNearExtremeFilter) return true;
   int tf = GetTradePeriod();
   int lookback = MathMax(1, InpNearExtremeLookback);
   int lowestIdx = iLowest(Symbol(), tf, MODE_LOW, lookback, 1);
   if(lowestIdx < 0) return true;
   double recentLow = Low[lowestIdx];
   if((Close[1] - recentLow) < InpNearExtremeATRMult * atr) return false;
   return true;
}

//+------------------------------------------------------------------+
//| RSI 过滤：超买禁止做多，超卖禁止做空                                |
//+------------------------------------------------------------------+
bool RSIAllowsLong()
{
   if(!InpUseRSIFilter) return true;
   int tf = GetTradePeriod();
   double rsi = iRSI(Symbol(), tf, InpRSIPeriod, PRICE_CLOSE, 1);
   if(rsi > InpRSILongMax) return false;
   return true;
}

bool RSIAllowsShort()
{
   if(!InpUseRSIFilter) return true;
   int tf = GetTradePeriod();
   double rsi = iRSI(Symbol(), tf, InpRSIPeriod, PRICE_CLOSE, 1);
   if(rsi < InpRSIShortMin) return false;
   return true;
}

//+------------------------------------------------------------------+
//| 创建“全部平仓”按钮                                                  |
//+------------------------------------------------------------------+
void CreateCloseAllButton()
{
   string btnName = "v8_CloseAllBtn";
   ObjectDelete(0, btnName);
   if(!ObjectCreate(0, btnName, OBJ_BUTTON, 0, 0, 0))
   {
      Print("[v8] 创建全部平仓按钮失败");
      return;
   }
   ObjectSetInteger(0, btnName, OBJPROP_XDISTANCE, 20);
   ObjectSetInteger(0, btnName, OBJPROP_YDISTANCE, 60);
   ObjectSetInteger(0, btnName, OBJPROP_XSIZE, 100);
   ObjectSetInteger(0, btnName, OBJPROP_YSIZE, 30);
   ObjectSetString(0, btnName, OBJPROP_TEXT, "全部平仓");
   ObjectSetInteger(0, btnName, OBJPROP_FONTSIZE, 10);
   ObjectSetInteger(0, btnName, OBJPROP_COLOR, clrWhite);
   ObjectSetInteger(0, btnName, OBJPROP_BGCOLOR, clrRed);
   ObjectSetInteger(0, btnName, OBJPROP_BORDER_TYPE, BORDER_FLAT);
   ObjectSetInteger(0, btnName, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, btnName, OBJPROP_HIDDEN, true);
}

//+------------------------------------------------------------------+
//| 一键平掉当前品种所有持仓和挂单                                        |
//+------------------------------------------------------------------+
void CloseAllOrders()
{
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) continue;
      if(OrderSymbol() != Symbol()) continue;

      bool ok = false;
      if(OrderType() == OP_BUY)
         ok = OrderClose(OrderTicket(), OrderLots(), Bid, InpSlippage, clrRed);
      else if(OrderType() == OP_SELL)
         ok = OrderClose(OrderTicket(), OrderLots(), Ask, InpSlippage, clrGreen);
      else if(OrderType() == OP_BUYLIMIT || OrderType() == OP_SELLLIMIT ||
              OrderType() == OP_BUYSTOP  || OrderType() == OP_SELLSTOP)
         ok = OrderDelete(OrderTicket(), clrYellow);

      if(!ok) LogError("全部平仓");
   }
   Print("[v8] 一键全部平仓完成");
}

//+------------------------------------------------------------------+
//| Expert initialization function                                      |
//+------------------------------------------------------------------+
int OnInit()
{
   g_lastBarTime = Time[0];
   ObjectDelete(0, "v8_micro_TimeLeft"); // 删除旧对象
   ObjectDelete(0, "battertest_V8_TimeLeft"); // 强制重新创建，避免位置等属性未更新
   RestorePosition();
   ShowInfo();
   CreateCloseAllButton();
   Print("[v8_micro] EA 初始化完成 品种=", Symbol(), " 时间周期=", InpTimeFrame, "M");
   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
//| Expert deinitialization function                                    |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   ObjectDelete(0, "v8_micro_TimeLeft");
   ObjectDelete(0, "battertest_V8_TimeLeft");
   ObjectDelete(0, "v8_CloseAllBtn");
   Comment("");
   Print("[v8_micro] EA 卸载");
}

//+------------------------------------------------------------------+
//| Expert tick function                                                |
//+------------------------------------------------------------------+
void OnTick()
{
   ShowInfo();
   CheckManualStopLoss();

   int tf = GetTradePeriod();

   datetime currentBarTime = iTime(Symbol(), tf, 0);
   if(currentBarTime == g_lastBarTime) return;
   g_lastBarTime = currentBarTime;

   //--- 获取指标值（上一根K线）
   double fastMA     = iMA(Symbol(), tf, InpFastMAPeriod, 0, MODE_SMA, PRICE_CLOSE, 1);
   double bbUpper    = iBands(Symbol(), tf, InpFastMAPeriod, InpFastBBMult, 0, PRICE_CLOSE, MODE_UPPER, 1);
   double bbLower    = iBands(Symbol(), tf, InpFastMAPeriod, InpFastBBMult, 0, PRICE_CLOSE, MODE_LOWER, 1);
   double atr        = iATR(Symbol(), tf, InpATRPeriod, 1);
   double slowMA     = iMA(Symbol(), tf, InpSlowMAPeriod, 0, MODE_SMA, PRICE_CLOSE, 1);
   double prevSlowMA = iMA(Symbol(), tf, InpSlowMAPeriod, 0, MODE_SMA, PRICE_CLOSE, InpSlowMAPeriod + 5);
   double maEntry1 = iMA(Symbol(), tf, InpEntryMA1, 0, MODE_SMA, PRICE_CLOSE, 1);
   double maEntry2 = iMA(Symbol(), tf, InpEntryMA2, 0, MODE_SMA, PRICE_CLOSE, 1);
   double maEntry3 = iMA(Symbol(), tf, InpEntryMA3, 0, MODE_SMA, PRICE_CLOSE, 1);
   double maEntry4 = iMA(Symbol(), tf, InpEntryMA4, 0, MODE_SMA, PRICE_CLOSE, 1);
   double maEntry1Prev = iMA(Symbol(), tf, InpEntryMA1, 0, MODE_SMA, PRICE_CLOSE, 2);
   double maEntry2Prev = iMA(Symbol(), tf, InpEntryMA2, 0, MODE_SMA, PRICE_CLOSE, 2);
   double maEntry3Prev = iMA(Symbol(), tf, InpEntryMA3, 0, MODE_SMA, PRICE_CLOSE, 2);
   double maEntry4Prev = iMA(Symbol(), tf, InpEntryMA4, 0, MODE_SMA, PRICE_CLOSE, 2);

   // MA5/20/60/80 交叉入场：本根 K 线刚完成多头排列/空头排列
   bool maCrossUp   = (maEntry1 > maEntry2 && maEntry1 > maEntry3 && maEntry1 > maEntry4) &&
                      !(maEntry1Prev > maEntry2Prev && maEntry1Prev > maEntry3Prev && maEntry1Prev > maEntry4Prev);
   bool maCrossDown = (maEntry1 < maEntry2 && maEntry1 < maEntry3 && maEntry1 < maEntry4) &&
                      !(maEntry1Prev < maEntry2Prev && maEntry1Prev < maEntry3Prev && maEntry1Prev < maEntry4Prev);

   // MA5/MA20 交叉平仓信号
   bool maFastCrossUpSlow  = (maEntry1 > maEntry2 && maEntry1Prev <= maEntry2Prev);
   bool maFastCrossDownSlow = (maEntry1 < maEntry2 && maEntry1Prev >= maEntry2Prev);

   if(atr == 0.0 || slowMA == 0.0 || maEntry1 == 0.0 || maEntry2 == 0.0 || maEntry3 == 0.0 || maEntry4 == 0.0) return;
   if(atr < 0.5)
   {
      Print("[v8_micro WARNING] ATR 异常过小 atr=", atr, " 跳过本根K线");
      return;
   }

   double closePrev = iClose(Symbol(), tf, 1);
   double highPrev  = iHigh(Symbol(), tf, 1);
   double lowPrev   = iLow(Symbol(), tf, 1);

   // MA20 回踩反转入场：价格在 MA60/MA80 上方，MA5 下穿 MA20 后重新上穿 MA20 做多；反之做空
   bool pullbackLong  = false;
   bool pullbackShort = false;
   if(InpUsePullbackEntry)
   {
      pullbackLong  = maFastCrossUpSlow && (closePrev > maEntry3) && (closePrev > maEntry4) && WasFastCrossDownSlow(InpPullbackLookback);
      pullbackShort = maFastCrossDownSlow && (closePrev < maEntry3) && (closePrev < maEntry4) && WasFastCrossUpSlow(InpPullbackLookback);
   }

   //--- 趋势方向
   int slowTrend = (closePrev > slowMA) ? 1 : -1;
   double slowSlope = slowMA - prevSlowMA;

   //--- 日线趋势过滤（可选）
   bool dailyLong = true, dailyShort = true;
   if(InpUseDailyTrend)
   {
      double dailyMA = iMA(Symbol(), PERIOD_D1, InpDailyMAPeriod, 0, MODE_SMA, PRICE_CLOSE, 1);
      double dailyClose = iClose(Symbol(), PERIOD_D1, 1);
      if(dailyClose <= dailyMA) dailyLong = false;
      if(dailyClose >= dailyMA) dailyShort = false;
   }

   //--- 持仓管理
   int posDir = GetPositionDir();
   if(posDir != 0)
   {
      double newSL = 0.0;
      if(posDir == 1)
      {
         if(iHigh(Symbol(), tf, 1) > g_highestHigh) g_highestHigh = iHigh(Symbol(), tf, 1);
         if(InpUseTrailingStop)
         {
            if(InpUseChandelierTrail)
               newSL = g_highestHigh - InpTrailATRMult * atr;
            else
               newSL = closePrev - InpTrailATRMult * atr;
            if(newSL > g_stopLoss) ModifyStopLoss(newSL);
         }

         // 保本止损
         double beATRLong = (InpUseFixedATRBreakeven && g_entryATR > 0.0) ? g_entryATR : atr;
         if(InpUseBreakeven && !g_breakevenMoved && closePrev >= g_entryPrice + InpBEProfitATRMult * beATRLong)
         {
            double beSL = g_entryPrice + InpBEATRMult * beATRLong;
            if(beSL > g_stopLoss)
            {
               ModifyStopLoss(beSL);
               g_breakevenMoved = true;
               Print("[v8_micro] 多单保本止损启动，新止损=", beSL, " 触发ATR=", beATRLong);
            }
         }

         // MA5 下穿 MA20 平多单
         if(maFastCrossDownSlow)
         {
            Print("[V8 EXIT] 多单 MA5 下穿 MA20 平仓 | close=", closePrev,
                  " | ma", InpEntryMA1, "=", DoubleToString(maEntry1, 3),
                  " | ma", InpEntryMA2, "=", DoubleToString(maEntry2, 3));
            ClosePosition();
            return;
         }

         if(lowPrev <= g_stopLoss)
         {
            Print("[v8_micro] 多单触发止损平仓 lowPrev=", lowPrev, " g_stopLoss=", g_stopLoss, " g_entryPrice=", g_entryPrice);
            ClosePosition();
         }
      }
      else if(posDir == -1)
      {
         if(iLow(Symbol(), tf, 1) < g_lowestLow) g_lowestLow = iLow(Symbol(), tf, 1);
         if(InpUseTrailingStop)
         {
            if(InpUseChandelierTrail)
               newSL = g_lowestLow + InpTrailATRMult * atr;
            else
               newSL = closePrev + InpTrailATRMult * atr;
            if(newSL < g_stopLoss || g_stopLoss == 0.0) ModifyStopLoss(newSL);
         }

         // 保本止损
         double beATRShort = (InpUseFixedATRBreakeven && g_entryATR > 0.0) ? g_entryATR : atr;
         if(InpUseBreakeven && !g_breakevenMoved && closePrev <= g_entryPrice - InpBEProfitATRMult * beATRShort)
         {
            double beSL = g_entryPrice - InpBEATRMult * beATRShort;
            if(beSL < g_stopLoss || g_stopLoss == 0.0)
            {
               ModifyStopLoss(beSL);
               g_breakevenMoved = true;
               Print("[v8_micro] 空单保本止损启动，新止损=", beSL, " 触发ATR=", beATRShort);
            }
         }

         // MA5 上穿 MA20 平空单
         if(maFastCrossUpSlow)
         {
            Print("[V8 EXIT] 空单 MA5 上穿 MA20 平仓 | close=", closePrev,
                  " | ma", InpEntryMA1, "=", DoubleToString(maEntry1, 3),
                  " | ma", InpEntryMA2, "=", DoubleToString(maEntry2, 3));
            ClosePosition();
            return;
         }

         if(highPrev >= g_stopLoss)
         {
            Print("[v8_micro] 空单触发止损平仓 highPrev=", highPrev, " g_stopLoss=", g_stopLoss, " g_entryPrice=", g_entryPrice);
            ClosePosition();
         }
      }
   }

   //--- 入场与反向逻辑
   posDir = GetPositionDir();

   // 趋势方向过滤
   bool trendOkLong  = true;
   bool trendOkShort = true;
   if(InpUseTrendDirection)
   {
      if(slowTrend != 1 || slowSlope <= 0) trendOkLong = false;
      if(slowTrend != -1 || slowSlope >= 0) trendOkShort = false;
   }

   // 成交量过滤
   bool volumeOk = true;
   if(InpUseVolumeFilter)
   {
      double volMA = VolumeMA(20, 1);
      if(volMA > 0.0 && (double)iVolume(Symbol(), tf, 1) < InpVolumeThreshold * volMA)
         volumeOk = false;
   }

   // 计算角度
   double maAngle = 0.0;
   double upperAngle = 0.0;
   if(InpUseAngleFilter)
   {
      maAngle = CalcMAAngle(1);
      upperAngle = CalcUpperAngle(1);
   }

   // MACD 金叉/死叉判断
   bool macdBullishCross = false, macdBearishCross = false;
   CheckMACDCross(macdBullishCross, macdBearishCross);

   // 近期极值过滤
   bool nearExtremeLongOk = NearExtremeAllowsLong(atr);
   bool nearExtremeShortOk = NearExtremeAllowsShort(atr);

   // RSI 过滤
   bool rsiLongOk = RSIAllowsLong();
   bool rsiShortOk = RSIAllowsShort();

   double angleMult = 1.0;
   bool angleOkLong = true, angleOkShort = true;
   if(InpUseAngleFilter)
   {
      double absAngle = MathAbs(maAngle);
      if(absAngle < InpMinAngle)
      {
         angleOkLong = false;
         angleOkShort = false;
      }
      else if(absAngle >= InpStrongAngle)
      {
         angleMult = 1.2;
      }
   }

   // MACD 过滤
   bool macdLongOk  = !(InpUseMACDFilter && InpMACDBanLongOnCross && macdBearishCross);
   bool macdShortOk = !(InpUseMACDFilter && InpMACDBanShortOnCross && macdBullishCross);

   bool longEntry  = trendOkLong && dailyLong && volumeOk && angleOkLong && macdLongOk && nearExtremeLongOk && rsiLongOk && (maCrossUp || pullbackLong);
   bool shortEntry = !InpOnlyLong && trendOkShort && dailyShort && volumeOk && angleOkShort && macdShortOk && nearExtremeShortOk && rsiShortOk && (maCrossDown || pullbackShort);

   //--- 详细调试日志：每根 K 线打印一次过滤状态
   static datetime lastLogTime = 0;
   datetime currBarTime = iTime(Symbol(), tf, 0);
   if(currBarTime != lastLogTime)
   {
      lastLogTime = currBarTime;
      Print("[V8 DEBUG] ", TimeToString(currBarTime, TIME_DATE|TIME_SECONDS),
            " | closePrev=", DoubleToString(closePrev, 3),
            " | fastMA=", DoubleToString(fastMA, 3),
            " | slowMA=", DoubleToString(slowMA, 3),
            " | slowTrend=", slowTrend,
            " | maAngle=", DoubleToString(maAngle, 2),
            " | upperAngle=", DoubleToString(upperAngle, 2),
            " | MinAngle=", InpMinAngle,
            " | angleOkL=", angleOkLong,
            " | angleOkS=", angleOkShort,
            " | rsi=", DoubleToString(iRSI(Symbol(), tf, InpRSIPeriod, PRICE_CLOSE, 1), 2),
            " | rsiLongOk=", rsiLongOk,
            " | rsiShortOk=", rsiShortOk,
            " | nearExtremeLongOk=", nearExtremeLongOk,
            " | nearExtremeShortOk=", nearExtremeShortOk,
            " | macdLongOk=", macdLongOk,
            " | macdShortOk=", macdShortOk,
            " | trendOkL=", trendOkLong,
            " | trendOkS=", trendOkShort,
            " | maCrossUp=", maCrossUp,
            " | maCrossDown=", maCrossDown,
            " | pullbackLong=", pullbackLong,
            " | pullbackShort=", pullbackShort,
            " | longEntry=", longEntry,
            " | shortEntry=", shortEntry);
   }

   // 做多信号：有空单先平仓，再开多单
   if(longEntry && posDir != 1)
   {
      if(posDir == -1)
      {
         Print("[V8 REVERSE] 空单平仓后反手做多 | ma_cross_up",
               " | close=", closePrev,
               " | ma", InpEntryMA1, "=", DoubleToString(maEntry1, 3),
               " | ma", InpEntryMA2, "=", DoubleToString(maEntry2, 3),
               " | ma", InpEntryMA3, "=", DoubleToString(maEntry3, 3),
               " | ma", InpEntryMA4, "=", DoubleToString(maEntry4, 3));
         ClosePosition();
      }
      if(!HasPosition())
      {
         Print("[V8 ENTRY] 开多单 | ma_cross_up",
               " | close=", closePrev,
               " | ma", InpEntryMA1, "=", DoubleToString(maEntry1, 3),
               " | ma", InpEntryMA2, "=", DoubleToString(maEntry2, 3),
               " | ma", InpEntryMA3, "=", DoubleToString(maEntry3, 3),
               " | ma", InpEntryMA4, "=", DoubleToString(maEntry4, 3));
         double sl = closePrev - InpStopATRMult * atr;
         OpenBuy(sl, angleMult);
      }
      return;
   }

   // 做空信号：有多单先平仓，再开空单
   if(shortEntry && posDir != -1)
   {
      if(posDir == 1)
      {
         Print("[V8 REVERSE] 多单平仓后反手做空 | ma_cross_down",
               " | close=", closePrev,
               " | ma", InpEntryMA1, "=", DoubleToString(maEntry1, 3),
               " | ma", InpEntryMA2, "=", DoubleToString(maEntry2, 3),
               " | ma", InpEntryMA3, "=", DoubleToString(maEntry3, 3),
               " | ma", InpEntryMA4, "=", DoubleToString(maEntry4, 3));
         ClosePosition();
      }
      if(!HasPosition())
      {
         Print("[V8 ENTRY] 开空单 | ma_cross_down",
               " | close=", closePrev,
               " | ma", InpEntryMA1, "=", DoubleToString(maEntry1, 3),
               " | ma", InpEntryMA2, "=", DoubleToString(maEntry2, 3),
               " | ma", InpEntryMA3, "=", DoubleToString(maEntry3, 3),
               " | ma", InpEntryMA4, "=", DoubleToString(maEntry4, 3));
         double sl = closePrev + InpStopATRMult * atr;
         OpenSell(sl, angleMult);
      }
      return;
   }
}

//+------------------------------------------------------------------+
//| 处理图表事件：点击“全部平仓”按钮                                      |
//+------------------------------------------------------------------+
void OnChartEvent(const int id, const long &lparam, const double &dparam, const string &sparam)
{
   if(id == CHARTEVENT_OBJECT_CLICK && sparam == "v8_CloseAllBtn")
   {
      CloseAllOrders();
      ObjectSetInteger(0, "v8_CloseAllBtn", OBJPROP_STATE, false);
   }
}
//+------------------------------------------------------------------+
