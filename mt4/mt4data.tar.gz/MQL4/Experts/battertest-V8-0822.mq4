//+------------------------------------------------------------------+
//|                               adaptive_trend_strategy_v8_micro.mq4|
//|                        v8 Micro 小资金固定手数 MT4 版本            |
//|  核心逻辑：                                                        |
//|  1. 可配置时间周期交易，双向                                       |
//|  2. Fast MA + Bollinger Bands 判断趋势与入场                       |
//|  3. ATR 计算止损与跟踪止损                                         |
//|  4. 慢周期 MA + 斜率 做趋势方向过滤                                |
//|  5. Donchian Channel 作为辅助入场                                  |
//|  6. 角度过滤（fast_ma / fast_upper）                               |
//|  7. 新增：UseFixedLot + FixedLotSize，固定开仓 0.01 手             |
//|  8. XAUUSD 15m 优选版 v1 默认参数                                  |
//+------------------------------------------------------------------+
#property copyright "v8 Micro MT4 Port"
#property link      ""
#property version   "1.00"
#property strict

#define PI 3.14159265358979323846

//--- 输入参数
input int    InpTimeFrame         = 15;      // 交易时间周期（分钟：1,5,15,30,60,240,1440）
input int    InpFastMAPeriod      = 21;      // Fast MA 周期
input double InpFastBBMult        = 1.5;     // 布林带倍数
input int    InpSlowMAPeriod      = 50;      // 慢周期 MA（趋势方向）
input int    InpATRPeriod         = 14;      // ATR 周期
input int    InpDonchianPeriod    = 20;      // 唐奇安通道周期
input double InpStopATRMult       = 2.5;     // 初始止损 ATR 倍数（XAUUSD 15m 扫描优化值）
input double InpTrailATRMult      = 4.0;     // 跟踪止损 ATR 倍数（XAUUSD 15m 回测优化值）
input bool   InpUseAngleFilter    = true;    // 启用角度过滤
input int    InpAngleLookback     = 3;       // 角度回望周期（XAUUSD 15m 扫描优化值）
input double InpMinAngle          = 30.0;    // 最小入场角度（度）（XAUUSD 15m 扫描优化值）
input double InpStrongAngle       = 55.0;    // 强角度阈值（度）
input bool   InpUseTrendDirection = true;    // 启用趋势方向过滤
input bool   InpUseVolumeFilter   = false;   // 启用成交量过滤
input double InpVolumeThreshold   = 1.0;     // 成交量需大于均量的倍数
input bool   InpUseDailyTrend     = false;   // 启用日线趋势过滤
input int    InpDailyMAPeriod     = 20;      // 日线 MA 周期
input bool   InpUseChandelierTrail = false;  // 启用吊灯线跟踪止损
input bool   InpUseBreakeven      = true;    // 启用保本止损
input double InpBEProfitATRMult   = 2.0;     // 浮盈达到 N*ATR 后启动保本
input double InpBEATRMult         = 2.0;     // 保本止损设为入场价 + N*ATR
input bool   InpOnlyLong          = false;   // 只做多
input bool   InpUseFixedLot       = true;    // 使用固定手数
input double InpFixedLotSize      = 0.01;    // 固定手数（XAUUSD 15m Micro 优选版）
input double InpRiskPercent       = 2.0;     // 单笔风险百分比（UseFixedLot=true 时无效）
input double InpMaxLot            = 10.0;    // 最大手数
input bool   InpShow              = true;    // 显示K线剩余时间（右上角黄色）
input double InpManualSLDollar    = 5.0;     // 手动单亏损达到多少美元自动止损（0=关闭）

//--- 止损后回踩再入场
input bool   InpUseReEntryAfterStop = true;   // 启用止损后同一日回踩再入场
input double InpReEntryATRTolerance = 0.3;    // 回踩价格容差（ATR倍数）

//--- MACD 过滤
input bool   InpUseMACDFilter     = false;   // 启用 MACD 过滤
input int    InpMACDFast          = 12;      // MACD 快线周期
input int    InpMACDSlow          = 26;      // MACD 慢线周期
input int    InpMACDSignal        = 9;       // MACD 信号线周期
input bool   InpMACDBanShortOnCross = true;  // MACD 金叉时禁止做空
input bool   InpMACDBanLongOnCross  = true;  // MACD 死叉时禁止做多

//--- 近期极值过滤
input bool   InpUseNearExtremeFilter = true;  // 启用近期极值过滤（XAUUSD 15m 扫描优化值）
input int    InpNearExtremeLookback  = 20;   // 近期极值回看 K 线数
input double InpNearExtremeATRMult   = 0.5;  // 距离极值小于 N*ATR 时不开仓
input int    InpMagicNumber       = 800809;  // 魔术号
input string InpTradeComment      = "v8_micro"; // 订单注释
input int    InpSlippage          = 30;      // 滑点（点）

//--- 全局变量
int    g_ticket = 0;
double g_entryPrice = 0.0;
double g_stopLoss = 0.0;
double g_highestHigh = 0.0;
double g_lowestLow = 0.0;
bool   g_breakevenMoved = false;
datetime g_lastBarTime = 0;
double   g_lastStoppedLongEntryPrice = 0.0; // 最近被止损多单的入场价
datetime g_lastStoppedLongTime = 0;         // 最近被止损多单的平仓时间
bool     g_lastLongWasStoppedOut = false;   // 最近一笔多单是否被止损
double   g_lastStoppedShortEntryPrice = 0.0; // 最近被止损空单的入场价
datetime g_lastStoppedShortTime = 0;         // 最近被止损空单的平仓时间
bool     g_lastShortWasStoppedOut = false;   // 最近一笔空单是否被止损

//+------------------------------------------------------------------+
//| 根据输入返回 MT4 时间周期枚举                                       |
//+------------------------------------------------------------------+
int GetTradePeriod()
{
   if(InpTimeFrame == 1) return PERIOD_M1;
   if(InpTimeFrame == 5) return PERIOD_M5;
   if(InpTimeFrame == 15) return PERIOD_M15;
   if(InpTimeFrame == 30) return PERIOD_M30;
   if(InpTimeFrame == 60) return PERIOD_H1;
   if(InpTimeFrame == 240) return PERIOD_H4;
   if(InpTimeFrame == 1440) return PERIOD_D1;
   return PERIOD_M15;
}

//+------------------------------------------------------------------+
//| 显示当前K线剩余时间（黄色大字，右上角）                              |
//+------------------------------------------------------------------+
void ShowInfo()
{
   if(!InpShow)
   {
      ObjectDelete(0, "v8_micro_TimeLeft");
      ObjectDelete(0, "battertest_V8_TimeLeft");
      Comment("");
      return;
   }
   int tf = GetTradePeriod();
   datetime barTime = iTime(Symbol(), tf, 0);
   if(barTime <= 0)
   {
      Print("[battertest-V8] ShowInfo 获取K线时间失败 tf=", tf);
      return;
   }
   int secondsPerBar = tf * 60;
   if(tf == PERIOD_D1) secondsPerBar = 86400;
   int elapsed = (int)(TimeCurrent() - barTime);
   if(elapsed < 0) elapsed = 0;
   int remaining = secondsPerBar - elapsed;
   if(remaining < 0) remaining = 0;

   string text = StringFormat("K线剩: %02d:%02d", remaining / 60, remaining % 60);

   string objName = "battertest_V8_TimeLeft";
   bool created = false;
   if(ObjectFind(0, objName) < 0)
   {
      created = ObjectCreate(0, objName, OBJ_LABEL, 0, 0, 0);
      if(!created)
      {
         Print("[battertest-V8] 创建时间标签失败，错误码=", GetLastError());
      }
      else
      {
         ObjectSetInteger(0, objName, OBJPROP_CORNER, CORNER_RIGHT_UPPER);
         ObjectSetInteger(0, objName, OBJPROP_XDISTANCE, 180);
         ObjectSetInteger(0, objName, OBJPROP_YDISTANCE, 20);
         ObjectSetInteger(0, objName, OBJPROP_BACK, false);
         ObjectSetInteger(0, objName, OBJPROP_SELECTABLE, false);
         ObjectSetString(0, objName, OBJPROP_FONT, "Arial");
         ObjectSetInteger(0, objName, OBJPROP_FONTSIZE, 20);
         ObjectSetInteger(0, objName, OBJPROP_COLOR, clrYellow);
      }
   }
   if(ObjectFind(0, objName) >= 0)
      ObjectSetString(0, objName, OBJPROP_TEXT, text);
}

//+------------------------------------------------------------------+
//| 检查手动单亏损并自动止损                                            |
//+------------------------------------------------------------------+
void CheckManualStopLoss()
{
   if(InpManualSLDollar <= 0.0) return;
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES))
      {
         if(OrderMagicNumber() == InpMagicNumber) continue;
         if(OrderSymbol() != Symbol()) continue;

         double profit = OrderProfit() + OrderSwap() + OrderCommission();
         if(profit <= -InpManualSLDollar)
         {
            int ticket = OrderTicket();
            bool ok = false;
            if(OrderType() == OP_BUY)
               ok = OrderClose(ticket, OrderLots(), Bid, InpSlippage, clrRed);
            else if(OrderType() == OP_SELL)
               ok = OrderClose(ticket, OrderLots(), Ask, InpSlippage, clrGreen);
            if(!ok) LogError("手动单止损平仓");
         }
      }
   }
}

//+------------------------------------------------------------------+
//| 计算成交量均线                                                      |
//+------------------------------------------------------------------+
double VolumeMA(int period, int shift)
{
   if(period <= 0) return 0.0;
   int tf = GetTradePeriod();
   double sum = 0.0;
   for(int i = shift; i < shift + period; i++)
   {
      long vol = iVolume(Symbol(), tf, i);
      if(vol < 0) return 0.0;
      sum += (double)vol;
   }
   return sum / period;
}

//+------------------------------------------------------------------+
//| 计算均线角度（度）                                                  |
//+------------------------------------------------------------------+
double CalcMAAngle(int shift)
{
   int tf = GetTradePeriod();
   double maNow = iMA(Symbol(), tf, InpFastMAPeriod, 0, MODE_SMA, PRICE_CLOSE, shift);
   double maPrev = iMA(Symbol(), tf, InpFastMAPeriod, 0, MODE_SMA, PRICE_CLOSE, shift + InpAngleLookback);
   if(maPrev == 0.0 || InpAngleLookback <= 0) return 0.0;
   return MathArctan((maNow - maPrev) / InpAngleLookback) * 180.0 / PI;
}

//+------------------------------------------------------------------+
//| 计算布林上轨角度（度）                                              |
//+------------------------------------------------------------------+
double CalcUpperAngle(int shift)
{
   int tf = GetTradePeriod();
   double upperNow = iBands(Symbol(), tf, InpFastMAPeriod, InpFastBBMult, 0, PRICE_CLOSE, MODE_UPPER, shift);
   double upperPrev = iBands(Symbol(), tf, InpFastMAPeriod, InpFastBBMult, 0, PRICE_CLOSE, MODE_UPPER, shift + InpAngleLookback);
   if(upperPrev == 0.0 || InpAngleLookback <= 0) return 0.0;
   return MathArctan((upperNow - upperPrev) / InpAngleLookback) * 180.0 / PI;
}

//+------------------------------------------------------------------+
//| 获取每个点的美元价值（近似）                                        |
//+------------------------------------------------------------------+
double GetPipValue()
{
   if(StringFind(Symbol(), "XAU") >= 0 || StringFind(Symbol(), "GOLD") >= 0)
      return 1.0;
   return MarketInfo(Symbol(), MODE_TICKVALUE) / MarketInfo(Symbol(), MODE_TICKSIZE) * Point;
}

//+------------------------------------------------------------------+
//| 计算手数：固定手数模式优先                                          |
//+------------------------------------------------------------------+
double CalcLotSize(double stopDistance, double angleMult)
{
   double lots;
   if(InpUseFixedLot)
   {
      lots = InpFixedLotSize;
   }
   else
   {
      if(stopDistance <= 0.0) return 0.0;
      double riskAmount = AccountBalance() * InpRiskPercent / 100.0;
      double tickSize   = MarketInfo(Symbol(), MODE_TICKSIZE);
      double tickValue  = MarketInfo(Symbol(), MODE_TICKVALUE);
      if(tickSize <= 0.0 || tickValue <= 0.0) return 0.0;
      lots = riskAmount * angleMult / (stopDistance / tickSize * tickValue);
   }

   double minLot = MarketInfo(Symbol(), MODE_MINLOT);
   double maxLot = MarketInfo(Symbol(), MODE_MAXLOT);
   double lotStep = MarketInfo(Symbol(), MODE_LOTSTEP);
   if(lotStep <= 0.0) lotStep = 0.01;

   lots = MathFloor(lots / lotStep) * lotStep;
   lots = MathMax(minLot, MathMin(maxLot, lots));
   lots = MathMin(lots, InpMaxLot);
   return NormalizeDouble(lots, 2);
}

//+------------------------------------------------------------------+
//| 检查当前是否有持仓                                                  |
//+------------------------------------------------------------------+
bool HasPosition()
{
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES))
      {
         if(OrderMagicNumber() == InpMagicNumber && OrderSymbol() == Symbol())
            return true;
      }
   }
   return false;
}

//+------------------------------------------------------------------+
//| 错误码转描述                                                        |
//+------------------------------------------------------------------+
string ErrorDescription(int error_code)
{
   switch(error_code)
   {
      case 0:   return "无错误";
      case 1:   return "无错误结果";
      case 2:   return "常见错误";
      case 3:   return "无效参数";
      case 4:   return "交易服务器繁忙";
      case 5:   return "旧版本客户端";
      case 6:   return "无连接";
      case 7:   return "非交易权限";
      case 8:   return "价格过高";
      case 9:   return "无效止损";
      case 10:  return "无效手数";
      case 11:  return "市场关闭";
      case 12:  return "禁止交易";
      case 13:  return "资金不足";
      case 14:  return "价格已变";
      case 15:  return "报价关闭";
      case 16:  return "自动交易关闭";
      case 17:  return "订单已处理";
      case 18:  return "禁止买入";
      case 19:  return "禁止卖出";
      case 20:  return "无效订单";
      case 21:  return "无效交易请求";
      case 22:  return "无最新报价";
      case 23:  return "无效价格";
      case 24:  return "无效止损";
      case 25:  return "无效止盈";
      case 26:  return "无效订单类型";
      case 27:  return "禁止交易";
      case 28:  return "交易被锁定";
      case 29:  return "订单被锁定";
      case 30:  return "无效成交";
      case 31:  return "无效请求";
      case 32:  return "无连接";
      case 33:  return "超时";
      case 34:  return "无效价格";
      case 35:  return "无效请求";
      case 36:  return "市场报价关闭";
      case 37:  return "交易被禁用";
      case 38:  return "无最新报价";
      case 39:  return "请求过于频繁";
      case 40:  return "自动交易关闭";
      case 41:  return "流水号已满";
      case 42:  return "禁止 Hedge";
      case 43:  return "禁止 FIFO";
      case 64:  return "账户被禁用";
      case 65:  return "无效账户";
      case 128: return "交易超时";
      case 129: return "无效价格";
      case 130: return "无效止损";
      case 131: return "无效手数";
      case 132: return "市场关闭";
      case 133: return "禁止交易";
      case 134: return "资金不足";
      case 135: return "价格已变";
      case 136: return "无报价";
      case 137: return "经纪商繁忙";
      case 138: return "重新报价";
      case 139: return "订单被锁定";
      case 140: return "仅允许平仓";
      case 141: return "交易限制";
      case 145: return "修改失败";
      case 146: return "交易环境繁忙";
      case 147: return "交易失败";
      case 148: return "无效订单";
      case 149: return "无效请求";
      case 150: return "无效参数";
      default:  return "未知错误";
   }
}

//+------------------------------------------------------------------+
//| 输出错误日志                                                        |
//+------------------------------------------------------------------+
void LogError(string action)
{
   int err = GetLastError();
   if(err != ERR_NO_ERROR)
   {
      Print("[v8_micro ERROR] ", action, " 错误码: ", err, " 描述: ", ErrorDescription(err));
   }
}

//+------------------------------------------------------------------+
//| 获取持仓方向：1=多，-1=空，0=无                                     |
//+------------------------------------------------------------------+
int GetPositionDir()
{
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES))
      {
         if(OrderMagicNumber() == InpMagicNumber && OrderSymbol() == Symbol())
         {
            if(OrderType() == OP_BUY)  return 1;
            if(OrderType() == OP_SELL) return -1;
         }
      }
   }
   return 0;
}

//+------------------------------------------------------------------+
//| 平掉当前持仓（带错误处理）                                          |
//+------------------------------------------------------------------+
void ClosePosition()
{
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES))
      {
         if(OrderMagicNumber() == InpMagicNumber && OrderSymbol() == Symbol())
         {
            int ticket = OrderTicket();
            bool ok = false;
            if(OrderType() == OP_BUY)
               ok = OrderClose(ticket, OrderLots(), Bid, InpSlippage, clrRed);
            else if(OrderType() == OP_SELL)
               ok = OrderClose(ticket, OrderLots(), Ask, InpSlippage, clrGreen);
            if(ok)
               Print("[v8_micro] 平仓成功 Ticket=", ticket, " 盈亏=", OrderProfit());
            else
               LogError("平仓");
         }
      }
   }
}

//+------------------------------------------------------------------+
//| 修改止损（带错误处理）                                              |
//+------------------------------------------------------------------+
void ModifyStopLoss(double newSL)
{
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES))
      {
         if(OrderMagicNumber() == InpMagicNumber && OrderSymbol() == Symbol())
         {
            double oldSL = OrderStopLoss();
            if(MathAbs(newSL - oldSL) > Point * 0.5)
            {
               bool ok = OrderModify(OrderTicket(), OrderOpenPrice(), NormalizeDouble(newSL, Digits), OrderTakeProfit(), 0, clrBlue);
               if(ok)
                  Print("[v8_micro] 移动止损 Ticket=", OrderTicket(), " 新止损=", newSL);
               else
                  LogError("移动止损");
            }
         }
      }
   }
}

//+------------------------------------------------------------------+
//| 开多单（带错误处理）                                                |
//+------------------------------------------------------------------+
void OpenBuy(double sl, double angleMult)
{
   double lots = CalcLotSize(MathAbs(Close[0] - sl), angleMult);
   if(lots <= 0.0)
   {
      Print("[v8_micro] 开多单失败：计算手数为0");
      return;
   }
   int ticket = OrderSend(Symbol(), OP_BUY, lots, Ask, InpSlippage, NormalizeDouble(sl, Digits), 0, InpTradeComment, InpMagicNumber, 0, clrGreen);
   if(ticket > 0)
   {
      g_ticket = ticket;
      g_entryPrice = Ask;
      g_stopLoss = sl;
      g_highestHigh = High[0];
      g_breakevenMoved = false;
      Print("[v8_micro] 开多单成功 Ticket=", ticket, " 手数=", lots, " 入场=", Ask, " 止损=", sl);
   }
   else
   {
      LogError("开多单");
   }
}

//+------------------------------------------------------------------+
//| 开空单（带错误处理）                                                |
//+------------------------------------------------------------------+
void OpenSell(double sl, double angleMult)
{
   double lots = CalcLotSize(MathAbs(sl - Close[0]), angleMult);
   if(lots <= 0.0)
   {
      Print("[v8_micro] 开空单失败：计算手数为0");
      return;
   }
   int ticket = OrderSend(Symbol(), OP_SELL, lots, Bid, InpSlippage, NormalizeDouble(sl, Digits), 0, InpTradeComment, InpMagicNumber, 0, clrRed);
   if(ticket > 0)
   {
      g_ticket = ticket;
      g_entryPrice = Bid;
      g_stopLoss = sl;
      g_lowestLow = Low[0];
      g_breakevenMoved = false;
      Print("[v8_micro] 开空单成功 Ticket=", ticket, " 手数=", lots, " 入场=", Bid, " 止损=", sl);
   }
   else
   {
      LogError("开空单");
   }
}

//+------------------------------------------------------------------+
//| EA 启动时恢复持仓状态                                               |
//+------------------------------------------------------------------+
void RestorePosition()
{
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES))
      {
         if(OrderMagicNumber() == InpMagicNumber && OrderSymbol() == Symbol())
         {
            g_ticket = OrderTicket();
            g_entryPrice = OrderOpenPrice();
            g_stopLoss = OrderStopLoss();
            int tf = GetTradePeriod();
            datetime openTime = OrderOpenTime();
            int barsSinceOpen = iBarShift(Symbol(), tf, openTime);
            if(barsSinceOpen < 1) barsSinceOpen = 1;
            if(OrderType() == OP_BUY)
            {
               int highestIdx = iHighest(Symbol(), tf, MODE_HIGH, barsSinceOpen, 1);
               g_highestHigh = iHigh(Symbol(), tf, highestIdx);
            }
            else
            {
               int lowestIdx = iLowest(Symbol(), tf, MODE_LOW, barsSinceOpen, 1);
               g_lowestLow = iLow(Symbol(), tf, lowestIdx);
            }
            Print("[v8_micro] 启动恢复持仓 Ticket=", g_ticket, " 方向=", (OrderType() == OP_BUY ? "多" : "空"),
                  " 入场=", g_entryPrice, " 止损=", g_stopLoss);
            return;
         }
      }
   }
}

//+------------------------------------------------------------------+
//| 检查最近一笔订单是否为止损平仓                                      |
//+------------------------------------------------------------------+
void CheckRecentStopOut()
{
   for(int i = OrdersHistoryTotal() - 1; i >= 0; i--)
   {
      if(OrderSelect(i, SELECT_BY_POS, MODE_HISTORY))
      {
         if(OrderMagicNumber() != InpMagicNumber || OrderSymbol() != Symbol()) continue;

         if(OrderType() == OP_BUY)
         {
            double sl = OrderStopLoss();
            double cp = OrderClosePrice();
            // 平仓价 <= 止损价 + 极小容差，视为被止损
            if(sl > 0 && cp <= sl + Point * 10)
            {
               g_lastStoppedLongEntryPrice = OrderOpenPrice();
               g_lastStoppedLongTime = OrderCloseTime();
               g_lastLongWasStoppedOut = true;
            }
            else
            {
               g_lastLongWasStoppedOut = false;
            }
            g_lastShortWasStoppedOut = false;
         }
         else if(OrderType() == OP_SELL)
         {
            double sl = OrderStopLoss();
            double cp = OrderClosePrice();
            // 平仓价 >= 止损价 - 极小容差，视为被止损
            if(sl > 0 && cp >= sl - Point * 10)
            {
               g_lastStoppedShortEntryPrice = OrderOpenPrice();
               g_lastStoppedShortTime = OrderCloseTime();
               g_lastShortWasStoppedOut = true;
            }
            else
            {
               g_lastShortWasStoppedOut = false;
            }
            g_lastLongWasStoppedOut = false;
         }
         return; // 只检查最近一笔
      }
   }
}

//+------------------------------------------------------------------+
//| MACD Histogram 值                                                   |
//+------------------------------------------------------------------+
double MACDHistogram(int shift)
{
   double macdMain = iMACD(Symbol(), GetTradePeriod(), InpMACDFast, InpMACDSlow, InpMACDSignal, PRICE_CLOSE, MODE_MAIN, shift);
   double macdSignal = iMACD(Symbol(), GetTradePeriod(), InpMACDFast, InpMACDSlow, InpMACDSignal, PRICE_CLOSE, MODE_SIGNAL, shift);
   return macdMain - macdSignal;
}

//+------------------------------------------------------------------+
//| 检查 MACD 是否金叉/死叉                                             |
//+------------------------------------------------------------------+
void CheckMACDCross(bool &bullishCross, bool &bearishCross)
{
   bullishCross = false;
   bearishCross = false;
   if(!InpUseMACDFilter) return;
   double histNow = MACDHistogram(1);
   double histPrev = MACDHistogram(2);
   if(histNow >= 0 && histPrev < 0) bullishCross = true;
   if(histNow < 0 && histPrev >= 0) bearishCross = true;
}

//+------------------------------------------------------------------+
//| 近期极值过滤                                                        |
//+------------------------------------------------------------------+
bool NearExtremeAllowsLong(double atr)
{
   if(!InpUseNearExtremeFilter) return true;
   int tf = GetTradePeriod();
   int lookback = MathMax(1, InpNearExtremeLookback);
   int highestIdx = iHighest(Symbol(), tf, MODE_HIGH, lookback, 1);
   if(highestIdx < 0) return true;
   double recentHigh = High[highestIdx];
   if((recentHigh - Close[1]) < InpNearExtremeATRMult * atr) return false;
   return true;
}

bool NearExtremeAllowsShort(double atr)
{
   if(!InpUseNearExtremeFilter) return true;
   int tf = GetTradePeriod();
   int lookback = MathMax(1, InpNearExtremeLookback);
   int lowestIdx = iLowest(Symbol(), tf, MODE_LOW, lookback, 1);
   if(lowestIdx < 0) return true;
   double recentLow = Low[lowestIdx];
   if((Close[1] - recentLow) < InpNearExtremeATRMult * atr) return false;
   return true;
}

//+------------------------------------------------------------------+
//| Expert initialization function                                      |
//+------------------------------------------------------------------+
int OnInit()
{
   g_lastBarTime = Time[0];
   ObjectDelete(0, "v8_micro_TimeLeft"); // 删除旧对象
   ObjectDelete(0, "battertest_V8_TimeLeft"); // 强制重新创建，避免位置等属性未更新
   RestorePosition();
   EventSetTimer(1); // 每秒刷新K线剩余时间
   Print("[v8_micro] EA 初始化完成 品种=", Symbol(), " 时间周期=", InpTimeFrame, "M");
   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
//| Expert deinitialization function                                    |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   EventKillTimer();
   ObjectDelete(0, "v8_micro_TimeLeft");
   ObjectDelete(0, "battertest_V8_TimeLeft");
   Comment("");
   Print("[v8_micro] EA 卸载");
}

//+------------------------------------------------------------------+
//| Timer function                                                      |
//+------------------------------------------------------------------+
void OnTimer()
{
   ShowInfo();
}

//+------------------------------------------------------------------+
//| Expert tick function                                                |
//+------------------------------------------------------------------+
void OnTick()
{
   ShowInfo();
   CheckManualStopLoss();

   int tf = GetTradePeriod();

   datetime currentBarTime = iTime(Symbol(), tf, 0);
   if(currentBarTime == g_lastBarTime) return;
   g_lastBarTime = currentBarTime;

   //--- 更新最近止损状态
   CheckRecentStopOut();

   //--- 获取指标值（上一根K线）
   double fastMA     = iMA(Symbol(), tf, InpFastMAPeriod, 0, MODE_SMA, PRICE_CLOSE, 1);
   double bbUpper    = iBands(Symbol(), tf, InpFastMAPeriod, InpFastBBMult, 0, PRICE_CLOSE, MODE_UPPER, 1);
   double bbLower    = iBands(Symbol(), tf, InpFastMAPeriod, InpFastBBMult, 0, PRICE_CLOSE, MODE_LOWER, 1);
   double atr        = iATR(Symbol(), tf, InpATRPeriod, 1);
   double slowMA     = iMA(Symbol(), tf, InpSlowMAPeriod, 0, MODE_SMA, PRICE_CLOSE, 1);
   double prevSlowMA = iMA(Symbol(), tf, InpSlowMAPeriod, 0, MODE_SMA, PRICE_CLOSE, InpSlowMAPeriod + 5);
   double dcUpper    = iHigh(Symbol(), tf, iHighest(Symbol(), tf, MODE_HIGH, InpDonchianPeriod, 1));
   double dcLower    = iLow(Symbol(), tf, iLowest(Symbol(), tf, MODE_LOW, InpDonchianPeriod, 1));

   if(fastMA == 0.0 || atr == 0.0 || slowMA == 0.0) return;

   double closePrev = Close[1];
   double highPrev  = High[1];
   double lowPrev   = Low[1];

   //--- 趋势方向
   int slowTrend = (closePrev > slowMA) ? 1 : -1;
   double slowSlope = slowMA - prevSlowMA;

   //--- 日线趋势过滤（可选）
   bool dailyLong = true, dailyShort = true;
   if(InpUseDailyTrend)
   {
      double dailyMA = iMA(Symbol(), PERIOD_D1, InpDailyMAPeriod, 0, MODE_SMA, PRICE_CLOSE, 1);
      double dailyClose = iClose(Symbol(), PERIOD_D1, 1);
      if(dailyClose <= dailyMA) dailyLong = false;
      if(dailyClose >= dailyMA) dailyShort = false;
   }

   //--- 持仓管理
   int posDir = GetPositionDir();
   if(posDir != 0)
   {
      double newSL = 0.0;
      if(posDir == 1)
      {
         if(High[1] > g_highestHigh) g_highestHigh = High[1];
         if(InpUseChandelierTrail)
            newSL = g_highestHigh - InpTrailATRMult * atr;
         else
            newSL = closePrev - InpTrailATRMult * atr;
         if(newSL > g_stopLoss) ModifyStopLoss(newSL);

         // 保本止损
         if(InpUseBreakeven && !g_breakevenMoved && closePrev >= g_entryPrice + InpBEProfitATRMult * atr)
         {
            double beSL = g_entryPrice + InpBEATRMult * atr;
            if(beSL > g_stopLoss)
            {
               ModifyStopLoss(beSL);
               g_breakevenMoved = true;
               Print("[v8_micro] 多单保本止损启动，新止损=", beSL);
            }
         }

         if(lowPrev <= g_stopLoss) ClosePosition();
      }
      else if(posDir == -1)
      {
         if(Low[1] < g_lowestLow) g_lowestLow = Low[1];
         if(InpUseChandelierTrail)
            newSL = g_lowestLow + InpTrailATRMult * atr;
         else
            newSL = closePrev + InpTrailATRMult * atr;
         if(newSL < g_stopLoss || g_stopLoss == 0.0) ModifyStopLoss(newSL);

         // 保本止损
         if(InpUseBreakeven && !g_breakevenMoved && closePrev <= g_entryPrice - InpBEProfitATRMult * atr)
         {
            double beSL = g_entryPrice - InpBEATRMult * atr;
            if(beSL < g_stopLoss || g_stopLoss == 0.0)
            {
               ModifyStopLoss(beSL);
               g_breakevenMoved = true;
               Print("[v8_micro] 空单保本止损启动，新止损=", beSL);
            }
         }

         if(highPrev >= g_stopLoss) ClosePosition();
      }
   }

   //--- 入场逻辑（无持仓时）
   if(HasPosition()) return;

   // 趋势方向过滤
   bool trendOkLong  = true;
   bool trendOkShort = true;
   if(InpUseTrendDirection)
   {
      if(slowTrend != 1 || slowSlope <= 0) trendOkLong = false;
      if(slowTrend != -1 || slowSlope >= 0) trendOkShort = false;
   }

   // 成交量过滤
   bool volumeOk = true;
   if(InpUseVolumeFilter)
   {
      double volMA = VolumeMA(20, 1);
      if(volMA > 0.0 && (double)iVolume(Symbol(), tf, 1) < InpVolumeThreshold * volMA)
         volumeOk = false;
   }

   // 计算角度
   double maAngle = 0.0;
   double upperAngle = 0.0;
   if(InpUseAngleFilter)
   {
      maAngle = CalcMAAngle(1);
      upperAngle = CalcUpperAngle(1);
   }

   // MACD 金叉/死叉判断
   bool macdBullishCross = false, macdBearishCross = false;
   CheckMACDCross(macdBullishCross, macdBearishCross);

   // 近期极值过滤
   bool nearExtremeLongOk = NearExtremeAllowsLong(atr);
   bool nearExtremeShortOk = NearExtremeAllowsShort(atr);

   double angleMult = 1.0;
   bool angleOkLong = true, angleOkShort = true;
   if(InpUseAngleFilter)
   {
      double absAngle = MathAbs(maAngle);
      if(absAngle < InpMinAngle)
      {
         angleOkLong = false;
         angleOkShort = false;
      }
      else if(absAngle >= InpStrongAngle)
      {
         angleMult = 1.2;
      }
   }

   // MACD 过滤
   bool macdLongOk  = !(InpUseMACDFilter && InpMACDBanLongOnCross && macdBearishCross);
   bool macdShortOk = !(InpUseMACDFilter && InpMACDBanShortOnCross && macdBullishCross);

   // trend_follow 入场
   if(trendOkLong && dailyLong && volumeOk && angleOkLong && macdLongOk && nearExtremeLongOk && closePrev > fastMA)
   {
      double sl = closePrev - InpStopATRMult * atr;
      OpenBuy(sl, angleMult);
      return;
   }

   if(!InpOnlyLong && trendOkShort && dailyShort && volumeOk && angleOkShort && macdShortOk && nearExtremeShortOk && closePrev < fastMA)
   {
      double sl = closePrev + InpStopATRMult * atr;
      OpenSell(sl, angleMult);
      return;
   }

   // donchian_breakout 辅助入场
   if(trendOkLong && dailyLong && volumeOk && angleOkLong && macdLongOk && nearExtremeLongOk && closePrev >= dcUpper)
   {
      double sl = closePrev - InpStopATRMult * atr;
      OpenBuy(sl, angleMult);
      return;
   }

   if(!InpOnlyLong && trendOkShort && dailyShort && volumeOk && angleOkShort && macdShortOk && nearExtremeShortOk && closePrev <= dcLower)
   {
      double sl = closePrev + InpStopATRMult * atr;
      OpenSell(sl, angleMult);
      return;
   }

   // 特殊：上一笔多单被扫损后，日内价格回到原入场位且MA21向上，则放宽条件再入场
   if(InpUseReEntryAfterStop && g_lastLongWasStoppedOut)
   {
      string stopDay = TimeToStr(g_lastStoppedLongTime, TIME_DATE);
      string today = TimeToStr(TimeCurrent(), TIME_DATE);
      if(stopDay == today)
      {
         double fastMAPrev = iMA(Symbol(), tf, InpFastMAPeriod, 0, MODE_SMA, PRICE_CLOSE, 2);
         bool ma21Up = (fastMA > fastMAPrev);
         double priceDist = MathAbs(closePrev - g_lastStoppedLongEntryPrice);
         double tol = InpReEntryATRTolerance * atr;

         // 保留趋势方向和日线过滤，放宽角度/成交量/MACD/极值过滤
         if(ma21Up && trendOkLong && dailyLong && priceDist <= tol)
         {
            double sl = closePrev - InpStopATRMult * atr;
            Print("[v8_micro] 触发止损后回踩再入场(多) 前入场价=", g_lastStoppedLongEntryPrice,
                  " 当前收盘价=", closePrev, " 容差=", tol, " MA21向上");
            OpenBuy(sl, 1.0);
            return;
         }
      }
   }

   // 特殊：上一笔空单被扫损后，日内价格回到原入场位且MA21向下，则放宽条件再入场
   if(!InpOnlyLong && InpUseReEntryAfterStop && g_lastShortWasStoppedOut)
   {
      string stopDay = TimeToStr(g_lastStoppedShortTime, TIME_DATE);
      string today = TimeToStr(TimeCurrent(), TIME_DATE);
      if(stopDay == today)
      {
         double fastMAPrev = iMA(Symbol(), tf, InpFastMAPeriod, 0, MODE_SMA, PRICE_CLOSE, 2);
         bool ma21Down = (fastMA < fastMAPrev);
         double priceDist = MathAbs(closePrev - g_lastStoppedShortEntryPrice);
         double tol = InpReEntryATRTolerance * atr;

         // 保留趋势方向和日线过滤，放宽角度/成交量/MACD/极值过滤
         if(ma21Down && trendOkShort && dailyShort && priceDist <= tol)
         {
            double sl = closePrev + InpStopATRMult * atr;
            Print("[v8_micro] 触发止损后回踩再入场(空) 前入场价=", g_lastStoppedShortEntryPrice,
                  " 当前收盘价=", closePrev, " 容差=", tol, " MA21向下");
            OpenSell(sl, 1.0);
            return;
         }
      }
   }
}
//+------------------------------------------------------------------+
