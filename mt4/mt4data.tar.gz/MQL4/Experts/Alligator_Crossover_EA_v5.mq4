//+------------------------------------------------------------------+
//|                                    Alligator_Crossover_EA_v5.mq4 |
//|                        鳄鱼线三线交叉策略 v5                       |
//|  改进点（退出逻辑优化）：                                          |
//|  1. 三线排列进场（黄>红>蓝 或 黄<红<蓝）                           |
//|  2. 多种退出模式：ATR跟踪 / 吊灯 / 保本后跟踪 / 分级收紧跟踪         |
//|  3. 初始止损：ATR 或 结构摆动低点/高点                              |
//|  4. 部分止盈：1.5R 平仓 50%，剩余跟踪                              |
//|  5. 仅做多选项（牛市专注）                                         |
//|  6. K线剩余时间显示（右上角黄色）                                   |
//+------------------------------------------------------------------+
#property copyright "Alligator Crossover v5"
#property link      ""
#property version   "5.00"
#property strict

//+------------------------------------------------------------------+
//| 输入参数                                                           |
//+------------------------------------------------------------------+
input double   Lots              = 0.02;     // 手数
input int      Slippage          = 30;       // 滑点（点）
input int      MagicNumber       = 20260805; // Magic 编号
input string   TradeComment      = "AlligatorV5"; // 订单注释

//--- 鳄鱼线参数
input int      JawPeriod         = 13;       // 下颌周期
input int      JawShift          = 8;        // 下颌平移
input int      TeethPeriod       = 8;        // 牙齿周期
input int      TeethShift        = 5;        // 牙齿平移
input int      LipsPeriod        = 5;        // 嘴唇周期
input int      LipsShift         = 3;        // 嘴唇平移
input ENUM_MA_METHOD     AlligatorMethod = MODE_SMMA;
input ENUM_APPLIED_PRICE AlligatorPrice  = PRICE_MEDIAN;

//--- 趋势过滤
input bool     UseTrendFilter    = true;     // 启用 H1 趋势过滤
input int      TrendMAPeriod     = 50;       // H1 趋势线周期

//--- ADX 过滤
input bool     UseADXFilter      = false;    // 启用 ADX 过滤
input int      ADXPeriod         = 14;       // ADX 周期
input double   ADXThreshold      = 20.0;     // ADX 阈值

//--- 确认 K 线
input bool     UseConfirmBar     = false;    // 启用确认 K 线

//--- ATR 止损与跟踪止损
input int      AtrPeriod         = 14;       // ATR 周期
input double   StopAtrMult       = 2.0;      // 初始止损 ATR 倍数
input double   TrailAtrMult      = 4.0;      // 跟踪止损 ATR 倍数

//--- 退出模式: 0=ATR跟踪 1=吊灯 2=保本后跟踪 3=分级收紧跟踪
input int      ExitMode          = 1;
//--- 初始止损模式: 0=ATR 1=结构摆动
input int      InitialStopMode   = 0;
input int      StructureLookback = 8;        // 结构摆动回看 K线数

//--- 部分止盈
input bool     UsePartialTakeProfit = false; // 启用 1.5R 部分止盈
input double   PartialTP_R_Mult  = 1.5;      // 部分止盈 R 倍数

//--- 仅做多
input bool     OnlyLong          = false;    // 仅做多

//--- 吊灯/保本/分级参数
input double   BreakevenAtrMult  = 1.5;      // 保本触发利润（ATR倍数）
input double   Tier2TrailMult    = 3.0;      // 分级跟踪第2档 ATR 倍数
input double   Tier3TrailMult    = 1.5;      // 分级跟踪第3档 ATR 倍数

//--- 信息显示
input bool     Show              = true;     // 显示 K 线剩余时间

//--- 手动单保护
input double   ManualSLDollar    = 5.0;      // 手动单亏损达到多少美元自动平仓（0=关闭）

//+------------------------------------------------------------------+
//| 全局变量                                                           |
//+------------------------------------------------------------------+
double g_entryPrice    = 0.0;
double g_stopLoss      = 0.0;
double g_initialStop   = 0.0;
double g_entryAtr      = 0.0;
double g_highestHigh   = 0.0;
double g_lowestLow     = 0.0;
bool   g_partialClosed = false;
double g_remainingLots = 0.0;
bool   g_breakevenMoved= false;

//+------------------------------------------------------------------+
//| 错误描述                                                           |
//+------------------------------------------------------------------+
string ErrorDescription(int error_code)
{
   switch(error_code)
   {
      case 0: return "无错误";
      case 1: return "无错误结果";
      case 2: return "常见错误";
      case 3: return "无效参数";
      case 4: return "交易服务器繁忙";
      case 5: return "旧版本客户端";
      case 6: return "无连接";
      case 7: return "非交易权限";
      case 8: return "价格过高";
      case 9: return "无效止损";
      case 10: return "无效手数";
      case 11: return "市场关闭";
      case 12: return "禁止交易";
      case 13: return "资金不足";
      case 14: return "价格已变";
      case 15: return "报价关闭";
      case 128: return "交易超时";
      case 129: return "无效价格";
      case 130: return "无效止损";
      case 131: return "无效手数";
      case 132: return "市场关闭";
      case 133: return "禁止交易";
      case 134: return "资金不足";
      case 135: return "价格已变";
      case 136: return "无报价";
      case 137: return "经纪商繁忙";
      case 138: return "重新报价";
      case 139: return "订单被锁定";
      case 140: return "仅允许平仓";
      case 141: return "交易限制";
      case 145: return "修改失败";
      default: return "未知错误";
   }
}

//+------------------------------------------------------------------+
//| 日志                                                               |
//+------------------------------------------------------------------+
void LogError(string action)
{
   int err = GetLastError();
   if(err != 0)
      Print("[AlligatorV5 ERROR] ", action, " 错误码: ", err, " 描述: ", ErrorDescription(err));
}

//+------------------------------------------------------------------+
//| 交易权限检查                                                       |
//+------------------------------------------------------------------+
bool CanTradeNow()
{
   if(!IsTradeAllowed(Symbol(), NULL)) return false;
   if(IsTradeContextBusy()) return false;
   if(MarketInfo(Symbol(), MODE_TRADEALLOWED) == 0) return false;
   return true;
}

//+------------------------------------------------------------------+
//| 显示 K 线剩余时间                                                  |
//+------------------------------------------------------------------+
void ShowRemainingTime()
{
   if(!Show)
   {
      ObjectDelete(0, "AT_AlligatorV5_Time");
      return;
   }
   if(ObjectFind(0, "AT_AlligatorV5_Time") < 0)
   {
      ObjectCreate(0, "AT_AlligatorV5_Time", OBJ_LABEL, 0, 0, 0);
      ObjectSetInteger(0, "AT_AlligatorV5_Time", OBJPROP_CORNER, CORNER_RIGHT_UPPER);
      ObjectSetInteger(0, "AT_AlligatorV5_Time", OBJPROP_XDISTANCE, 180);
      ObjectSetInteger(0, "AT_AlligatorV5_Time", OBJPROP_YDISTANCE, 45);
      ObjectSetString(0, "AT_AlligatorV5_Time", OBJPROP_FONT, "Arial Bold");
      ObjectSetInteger(0, "AT_AlligatorV5_Time", OBJPROP_FONTSIZE, 14);
      ObjectSetInteger(0, "AT_AlligatorV5_Time", OBJPROP_COLOR, clrYellow);
      ObjectSetInteger(0, "AT_AlligatorV5_Time", OBJPROP_TIMEFRAMES, OBJ_ALL_PERIODS);
   }
   datetime nextBarTime = Time[0] + Period() * 60;
   int remaining = (int)(nextBarTime - TimeCurrent());
   if(remaining < 0) remaining = 0;
   string txt = StringFormat("K线剩余: %02d:%02d", remaining / 60, remaining % 60);
   ObjectSetString(0, "AT_AlligatorV5_Time", OBJPROP_TEXT, txt);
}

//+------------------------------------------------------------------+
//| 手动单亏损保护                                                     |
//+------------------------------------------------------------------+
void CheckManualPositions()
{
   if(ManualSLDollar <= 0) return;
   if(!CanTradeNow()) return;

   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) continue;
      if(OrderSymbol() != Symbol()) continue;
      if(OrderMagicNumber() == MagicNumber) continue; // 只保护非本 EA 的单子

      double totalLoss = OrderProfit() + OrderSwap() + OrderCommission();
      if(totalLoss <= -ManualSLDollar)
      {
         double price = (OrderType() == OP_BUY) ? Bid : Ask;
         bool ok = OrderClose(OrderTicket(), OrderLots(), price, Slippage, clrRed);
         if(!ok) LogError("手动单平仓");
         else Print("[AlligatorV5] 手动单亏损保护平仓 Ticket=", OrderTicket(),
                    " 亏损=", DoubleToString(totalLoss, 2), " USD");
      }
   }
}

//+------------------------------------------------------------------+
//| 获取持仓方向                                                       |
//+------------------------------------------------------------------+
int GetPositionDir()
{
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES))
      {
         if(OrderMagicNumber() != MagicNumber) continue;
         if(OrderSymbol() != Symbol()) continue;
         if(OrderType() == OP_BUY) return 1;
         if(OrderType() == OP_SELL) return -1;
      }
   }
   return 0;
}

//+------------------------------------------------------------------+
//| 平仓全部                                                           |
//+------------------------------------------------------------------+
void ClosePosition(int orderType)
{
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) continue;
      if(OrderMagicNumber() != MagicNumber) continue;
      if(OrderSymbol() != Symbol()) continue;
      if(OrderType() != orderType) continue;

      double price = (orderType == OP_BUY) ? Bid : Ask;
      bool ok = OrderClose(OrderTicket(), OrderLots(), price, Slippage, clrRed);
      if(!ok) LogError("平仓");
      else Print("[AlligatorV5] 平仓 Ticket=", OrderTicket(), " 类型=", orderType);
   }
}

//+------------------------------------------------------------------+
//| 部分平仓 50%                                                        |
//+------------------------------------------------------------------+
void PartialClose(int orderType)
{
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) continue;
      if(OrderMagicNumber() != MagicNumber) continue;
      if(OrderSymbol() != Symbol()) continue;
      if(OrderType() != orderType) continue;

      double origLots = OrderLots();
      double lotsToClose = NormalizeDouble(origLots / 2.0, 2);
      if(lotsToClose < MarketInfo(Symbol(), MODE_MINLOT)) lotsToClose = origLots;
      double price = (orderType == OP_BUY) ? Bid : Ask;
      bool ok = OrderClose(OrderTicket(), lotsToClose, price, Slippage, clrGreen);
      if(!ok)
      {
         LogError("部分平仓");
      }
      else
      {
         g_partialClosed = true;
         g_remainingLots = origLots - lotsToClose;
         Print("[AlligatorV5] 部分平仓 Ticket=", OrderTicket(), " 手数=", lotsToClose, " 剩余=", g_remainingLots);
      }
   }
}

//+------------------------------------------------------------------+
//| 开仓                                                               |
//+------------------------------------------------------------------+
void OpenOrder(int orderType, double lots, double sl)
{
   double price = (orderType == OP_BUY) ? Ask : Bid;
   int ticket = OrderSend(Symbol(), orderType, lots, price, Slippage, NormalizeDouble(sl, Digits), 0, TradeComment, MagicNumber, 0, clrBlue);
   if(ticket < 0)
   {
      LogError("开仓");
   }
   else
   {
      g_entryPrice     = price;
      g_stopLoss       = sl;
      g_initialStop    = sl;
      g_entryAtr       = iATR(Symbol(), Period(), AtrPeriod, 1);
      g_highestHigh    = High[1];
      g_lowestLow      = Low[1];
      g_partialClosed  = false;
      g_remainingLots  = lots;
      g_breakevenMoved = false;
      Print("[AlligatorV5] 开仓 Ticket=", ticket, " 类型=", orderType, " 价格=", price, " 止损=", sl, " 手数=", lots);
   }
}

//+------------------------------------------------------------------+
//| 修改止损                                                           |
//+------------------------------------------------------------------+
void ModifySL(double newSL)
{
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) continue;
      if(OrderMagicNumber() != MagicNumber) continue;
      if(OrderSymbol() != Symbol()) continue;
      double oldSL = OrderStopLoss();
      if(MathAbs(newSL - oldSL) > Point * 0.5)
      {
         bool ok = OrderModify(OrderTicket(), OrderOpenPrice(), NormalizeDouble(newSL, Digits), OrderTakeProfit(), 0, clrBlue);
         if(!ok) LogError("移动止损");
         else g_stopLoss = newSL;
      }
   }
}

//+------------------------------------------------------------------+
//| 结构止损（摆动低/高点）                                             |
//+------------------------------------------------------------------+
double StructureStop(int orderType)
{
   int lb = MathMax(1, StructureLookback);
   if(orderType == OP_BUY)
   {
      int idx = iLowest(Symbol(), Period(), MODE_LOW, lb, 1);
      if(idx < 0) return Low[1];
      return Low[idx];
   }
   else
   {
      int idx = iHighest(Symbol(), Period(), MODE_HIGH, lb, 1);
      if(idx < 0) return High[1];
      return High[idx];
   }
}

//+------------------------------------------------------------------+
//| 初始化                                                             |
//+------------------------------------------------------------------+
int OnInit()
{
   Print("Alligator Crossover v5 initialized. Magic=", MagicNumber);
   ShowRemainingTime();
   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
//| 反初始化                                                           |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   ObjectDelete(0, "AT_AlligatorV5_Time");
   Print("Alligator Crossover v5 deinitialized.");
}

//+------------------------------------------------------------------+
//| 主循环                                                             |
//+------------------------------------------------------------------+
void OnTick()
{
   ShowRemainingTime();
   CheckManualPositions(); // 每 Tick 检查手动单亏损保护

   static datetime lastBarTime = 0;
   datetime currBarTime = iTime(Symbol(), Period(), 0);
   if(currBarTime == lastBarTime) return;
   lastBarTime = currBarTime;

   //--- 鳄鱼线（上一根收盘 K 线，shift=1）
   double jaw1   = iAlligator(Symbol(), Period(), JawPeriod, JawShift, TeethPeriod, TeethShift,
                              LipsPeriod, LipsShift, AlligatorMethod, AlligatorPrice,
                              MODE_GATORJAW, 1);
   double teeth1 = iAlligator(Symbol(), Period(), JawPeriod, JawShift, TeethPeriod, TeethShift,
                              LipsPeriod, LipsShift, AlligatorMethod, AlligatorPrice,
                              MODE_GATORTEETH, 1);
   double lips1  = iAlligator(Symbol(), Period(), JawPeriod, JawShift, TeethPeriod, TeethShift,
                              LipsPeriod, LipsShift, AlligatorMethod, AlligatorPrice,
                              MODE_GATORLIPS, 1);

   //--- 前一根 K 线用于确认交叉
   double jaw2   = iAlligator(Symbol(), Period(), JawPeriod, JawShift, TeethPeriod, TeethShift,
                              LipsPeriod, LipsShift, AlligatorMethod, AlligatorPrice,
                              MODE_GATORJAW, 2);
   double teeth2 = iAlligator(Symbol(), Period(), JawPeriod, JawShift, TeethPeriod, TeethShift,
                              LipsPeriod, LipsShift, AlligatorMethod, AlligatorPrice,
                              MODE_GATORTEETH, 2);
   double lips2  = iAlligator(Symbol(), Period(), JawPeriod, JawShift, TeethPeriod, TeethShift,
                              LipsPeriod, LipsShift, AlligatorMethod, AlligatorPrice,
                              MODE_GATORLIPS, 2);

   if(jaw1 == EMPTY_VALUE || teeth1 == EMPTY_VALUE || lips1 == EMPTY_VALUE) return;
   if(jaw2 == EMPTY_VALUE || teeth2 == EMPTY_VALUE || lips2 == EMPTY_VALUE) return;

   //--- ATR
   double atr = iATR(Symbol(), Period(), AtrPeriod, 1);
   if(atr == 0 || atr == EMPTY_VALUE) return;

   //--- H1 趋势过滤
   int trendDir = 0;
   if(UseTrendFilter)
   {
      double h1_ma0 = iMA(Symbol(), PERIOD_H1, TrendMAPeriod, 0, MODE_SMA, PRICE_CLOSE, 0);
      double h1_ma1 = iMA(Symbol(), PERIOD_H1, TrendMAPeriod, 0, MODE_SMA, PRICE_CLOSE, 1);
      if(h1_ma0 > h1_ma1) trendDir = 1;
      else if(h1_ma0 < h1_ma1) trendDir = -1;
   }

   //--- ADX 过滤
   bool adxOk = true;
   if(UseADXFilter)
   {
      double adx = iADX(Symbol(), Period(), ADXPeriod, PRICE_CLOSE, MODE_MAIN, 1);
      adxOk = (adx >= ADXThreshold);
   }

   //--- 当前/前一根 K 线排列状态（-1/0/1）
   bool long1  = (lips1 > teeth1) && (teeth1 > jaw1);
   bool short1 = (lips1 < teeth1) && (teeth1 < jaw1);
   bool long2  = (lips2 > teeth2) && (teeth2 > jaw2);
   bool short2 = (lips2 < teeth2) && (teeth2 < jaw2);

   int currAlign = long1 ? 1 : (short1 ? -1 : 0);
   int prevAlign = long2 ? 1 : (short2 ? -1 : 0);

   //--- 持仓管理
   int posDir = GetPositionDir();
   if(posDir == 1)
   {
      // 更新持仓期间最高/最低价
      if(High[1] > g_highestHigh) g_highestHigh = High[1];

      // 部分止盈
      if(UsePartialTakeProfit && !g_partialClosed)
      {
         double risk = MathAbs(g_entryPrice - g_initialStop);
         if(risk > 0 && High[1] >= g_entryPrice + PartialTP_R_Mult * risk)
         {
            PartialClose(OP_BUY);
         }
      }

      // 跟踪止损
      double newSL = g_stopLoss;
      if(ExitMode == 0) // ATR 跟踪
      {
         newSL = Close[1] - TrailAtrMult * atr;
      }
      else if(ExitMode == 1) // 吊灯
      {
         newSL = g_highestHigh - TrailAtrMult * atr;
      }
      else if(ExitMode == 2) // 保本后跟踪
      {
         double profit = Close[1] - g_entryPrice;
         if(!g_breakevenMoved && profit >= BreakevenAtrMult * g_entryAtr)
         {
            newSL = g_entryPrice;
            g_breakevenMoved = true;
         }
         else if(g_breakevenMoved)
         {
            newSL = Close[1] - TrailAtrMult * atr;
         }
      }
      else if(ExitMode == 3) // 分级收紧跟踪
      {
         double profit = Close[1] - g_entryPrice;
         double mult = TrailAtrMult;
         if(profit >= 4.0 * g_entryAtr) mult = Tier3TrailMult;
         else if(profit >= 2.0 * g_entryAtr) mult = Tier2TrailMult;
         newSL = Close[1] - mult * atr;
      }

      if(newSL > g_stopLoss) ModifySL(newSL);

      if(Low[1] <= g_stopLoss)
      {
         ClosePosition(OP_BUY);
      }
   }
   else if(posDir == -1)
   {
      // 更新持仓期间最低/最高价
      if(Low[1] < g_lowestLow) g_lowestLow = Low[1];

      // 部分止盈
      if(UsePartialTakeProfit && !g_partialClosed)
      {
         double risk = MathAbs(g_entryPrice - g_initialStop);
         if(risk > 0 && Low[1] <= g_entryPrice - PartialTP_R_Mult * risk)
         {
            PartialClose(OP_SELL);
         }
      }

      // 跟踪止损
      double newSL = g_stopLoss;
      if(ExitMode == 0) // ATR 跟踪
      {
         newSL = Close[1] + TrailAtrMult * atr;
      }
      else if(ExitMode == 1) // 吊灯
      {
         newSL = g_lowestLow + TrailAtrMult * atr;
      }
      else if(ExitMode == 2) // 保本后跟踪
      {
         double profit = g_entryPrice - Close[1];
         if(!g_breakevenMoved && profit >= BreakevenAtrMult * g_entryAtr)
         {
            newSL = g_entryPrice;
            g_breakevenMoved = true;
         }
         else if(g_breakevenMoved)
         {
            newSL = Close[1] + TrailAtrMult * atr;
         }
      }
      else if(ExitMode == 3) // 分级收紧跟踪
      {
         double profit = g_entryPrice - Close[1];
         double mult = TrailAtrMult;
         if(profit >= 4.0 * g_entryAtr) mult = Tier3TrailMult;
         else if(profit >= 2.0 * g_entryAtr) mult = Tier2TrailMult;
         newSL = Close[1] + mult * atr;
      }

      if(newSL < g_stopLoss || g_stopLoss == 0.0) ModifySL(newSL);

      if(High[1] >= g_stopLoss)
      {
         ClosePosition(OP_SELL);
      }
   }

   //--- 入场逻辑
   if(posDir != 0) return;
   if(!adxOk) return;

   // 多头排列刚形成 -> 做多
   if(currAlign == 1 && prevAlign == 0)
   {
      if(!UseTrendFilter || trendDir == 0 || trendDir == 1)
      {
         if(!UseConfirmBar || Close[1] > Open[1])
         {
            double sl;
            if(InitialStopMode == 1)
               sl = StructureStop(OP_BUY);
            else
               sl = NormalizeDouble(Ask - StopAtrMult * atr, Digits);
            OpenOrder(OP_BUY, Lots, sl);
         }
      }
   }

   // 空头排列刚形成 -> 做空
   if(currAlign == -1 && prevAlign == 0 && !OnlyLong)
   {
      if(!UseTrendFilter || trendDir == 0 || trendDir == -1)
      {
         if(!UseConfirmBar || Close[1] < Open[1])
         {
            double sl;
            if(InitialStopMode == 1)
               sl = StructureStop(OP_SELL);
            else
               sl = NormalizeDouble(Bid + StopAtrMult * atr, Digits);
            OpenOrder(OP_SELL, Lots, sl);
         }
      }
   }
}
//+------------------------------------------------------------------+
